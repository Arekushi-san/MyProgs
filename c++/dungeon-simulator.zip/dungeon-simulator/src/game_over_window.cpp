#include "game_over_window.hpp"
#include <QPainter>
#include <QFont>

game_over_window::game_over_window(QWidget *parent) : QWidget(parent) {
    setWindowTitle("Game Over");
    setFixedSize(300, 200);  // Taille fixe de la fenêtre
}

void game_over_window::paintEvent(QPaintEvent *event) {
    QPainter painter(this);
    
    painter.setPen(Qt::black);
    painter.setFont(QFont("Arial", 24));

    // Dessiner le texte "Game Over"
    painter.drawText(50, 100, "Game Over");
}
