#include "render_area.hpp"
#include <QPainter>
#include <QKeyEvent>
#include <QApplication>
#include <iostream>

#include "bloc/bloc.hpp"
#include "bloc/chemin.hpp"
#include "bloc/entree.hpp"
#include "bloc/hole.hpp"
#include "bloc/mur.hpp"
#include "bloc/porte.hpp"
#include "bloc/sortie.hpp"

#include "entity/enemy.hpp"
#include "entity/entity.hpp"
#include "entity/epee.hpp"
#include "entity/joueur.hpp"
#include "entity/cle.hpp"
#include "map_game.hpp"

render_area::render_area(QWidget *parent) : QWidget(parent), game(nullptr) {
    setWindowState(Qt::WindowFullScreen);  // Plein écran
    infoWindow = new info_window();  // Créer la fenêtre d'informations
    infoWindow->show();  // Afficher la fenêtre d'informations
    gameOverWindow = nullptr;  // Initialiser le pointeur de la fenêtre Game Over
}

void render_area::setMaze(map_game *g) {
    game = g;
    update();
}

void render_area::checkExit() {
    if (!game) return;

    auto player = game->getPlayer();

    if (player->getPosX() == game->get_sortiex() && player->getPosY() == game->get_sortiey()) {
        game->add_etage();  // Incrémente l'étage lors de la sortie du niveau
        game->generateMaze();
        game->ajout_obj();
        setMaze(game);
    }

    // Mettre à jour les informations de la fenêtre infoWindow
    infoWindow->updateInfo(player->getScore(), game->get_etage(), player->getNbEpee(), player->getLife(), player->getNb_cle());
}

void render_area::checkGameOver() {
    if (!game) return;

    auto player = game->getPlayer();

    // Si la vie du joueur est égale ou inférieure à 0, afficher Game Over
    if (player->getLife() <= 0) {
        // Afficher la fenêtre Game Over
        if (!gameOverWindow) {
            gameOverWindow = new game_over_window();
            gameOverWindow->show();  // Afficher la fenêtre Game Over
        }

        // Fermer la fenêtre principale
        this->close();
    }
}

void render_area::paintEvent(QPaintEvent *event) {
    if (!game) return;

    QPainter painter(this);
    int cellSize = 20;
    auto maze = game->getMaze();

    // Dessin du labyrinthe
    for (size_t y = 0; y < maze.size(); y++) {
        for (size_t x = 0; x < maze[0].size(); x++) {
            if (maze[x][y]->getLife() <= 0 && dynamic_cast<enemy*>(maze[x][y])) {
                maze[x][y] = new chemin(x, y);
            }

            if (dynamic_cast<mur*>(maze[x][y])) {
                painter.fillRect(QRect(x * cellSize, y * cellSize, cellSize, cellSize), Qt::black);
            } else if (dynamic_cast<entree*>(maze[x][y])) {
                painter.fillRect(QRect(x * cellSize, y * cellSize, cellSize, cellSize), Qt::green);
            } else if (dynamic_cast<sortie*>(maze[x][y])) {
                painter.fillRect(QRect(x * cellSize, y * cellSize, cellSize, cellSize), Qt::yellow);
            } else if (dynamic_cast<chemin*>(maze[x][y])) {
                painter.fillRect(QRect(x * cellSize, y * cellSize, cellSize, cellSize), Qt::white);
            } else if (dynamic_cast<enemy*>(maze[x][y])) {
                painter.fillRect(QRect(x * cellSize, y * cellSize, cellSize, cellSize), Qt::red);
            } else if (dynamic_cast<porte*>(maze[x][y])) {
                painter.fillRect(QRect(x * cellSize, y * cellSize, cellSize, cellSize), Qt::gray);
            } else if (dynamic_cast<cle*>(maze[x][y])) {
                painter.fillRect(QRect(x * cellSize, y * cellSize, cellSize, cellSize), Qt::cyan);
            } else if (dynamic_cast<epee*>(maze[x][y])) {
                painter.fillRect(QRect(x * cellSize, y * cellSize, cellSize, cellSize), Qt::magenta);
            } else if (dynamic_cast<hole*>(maze[x][y])) {
                painter.fillRect(QRect(x * cellSize, y * cellSize, cellSize, cellSize), Qt::darkCyan);
            }
        }
    }

    auto player = game->getPlayer();
    painter.fillRect(QRect(player->getPosX() * cellSize, player->getPosY() * cellSize, cellSize, cellSize), Qt::blue);
    
    checkExit();
    checkGameOver();  // Vérifier la fin du jeu après chaque action
}

bool render_area::isValidMove(int new_x, int new_y) {
    auto maze = game->getMaze();
    auto player = game->getPlayer();
    int scoretemp=0;
    bool Notvalid=true;
    
    //sortie des limites du dongeon
    if (new_x < 0 || new_x >= static_cast<int>(maze.size()) ||
        new_y < 0 || new_y >= static_cast<int>(maze[0].size())) {
        return false;
    }


    if (dynamic_cast<cle*>(maze[new_x][new_y])) {
        player->addNb_cle();
        maze[new_x][new_y]->loseLife();
        std::cout << "\ngain de cle\n";

        maze[new_x][new_y]->setThrough();
        game->modifCase(new_x, new_y);
        scoretemp=50;
    }

    else if (dynamic_cast<porte*>(maze[new_x][new_y]) && player->getNb_cle()>=1) {
        player->loseCle();
        maze[new_x][new_y]->loseLife();
        std::cout << "\nporte ouverte\n";

        maze[new_x][new_y]->setThrough();
        game->modifCase(new_x, new_y);
        scoretemp=500;
    }

    else if (dynamic_cast<enemy*>(maze[new_x][new_y])) {
        
        if(player->getNbEpee()>=1){
            player->loseEpee();
            maze[new_x][new_y]->loseLife();
            std::cout << "\nenemy tué\n";
            maze[new_x][new_y]->setThrough();
            game->modifCase(new_x, new_y);
            scoretemp=5000;
        }
        else{
            player->loseLife();
        }
        
    }

    else if (dynamic_cast<epee*>(maze[new_x][new_y])) {
        player->addNbEpee();
        maze[new_x][new_y]->loseLife();
        std::cout << "\ngain epee\n";

        maze[new_x][new_y]->setThrough();
        game->modifCase(new_x, new_y);
        scoretemp=5000;
    }

    else if (dynamic_cast<hole*>(maze[new_x][new_y])) {
        player->setPosition(game->get_entreex(), game->get_entreey());
        std::cout << "<\nteleport joueur\n";
        Notvalid=false;
        game->modifCase(new_x, new_y);
        scoretemp=-300;
    }

    player->addScore(scoretemp);
    return maze[new_x][new_y]->getThrough() && Notvalid;;
}

void render_area::movePlayer(int dx, int dy) {
    if (!game) return;

    auto player = game->getPlayer();
    int new_x = player->getPosX() + dx;
    int new_y = player->getPosY() + dy;

    if (isValidMove(new_x, new_y)) {
        player->setPosition(new_x, new_y);
        checkExit();
         
    }
    update();  
    infoWindow->updateInfo(player->getScore(), game->get_etage(), player->getNbEpee(), player->getLife(), player->getNb_cle());

}

void render_area::keyPressEvent(QKeyEvent *event) {
    if (!game) return;

    switch (event->key()) {
        case Qt::Key_Up: movePlayer(0, -1); break;
        case Qt::Key_Down: movePlayer(0, 1); break;
        case Qt::Key_Left: movePlayer(-1, 0); break;
        case Qt::Key_Right: movePlayer(1, 0); break;
        case Qt::Key_Escape: QApplication::quit(); break;
        default: QWidget::keyPressEvent(event);
    }   
}
