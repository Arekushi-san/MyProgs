#include "window.hpp"
#include "ui_mainwindow.h"

window::window(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow), render(new render_area(this)){
    ui->setupUi(this);

    map_game *game = new map_game(21, 21);
    game->init();
    render->setMaze(game);

    ui->verticalLayout->addWidget(render);
    ui->verticalLayout->setAlignment(Qt::AlignTop);
    render->setFixedSize(420, 420);

    connect(ui->upButton, &QPushButton::clicked, this, &window::move_up);
    connect(ui->downButton, &QPushButton::clicked, this, &window::move_down);
    connect(ui->leftButton, &QPushButton::clicked, this, &window::move_left);
    connect(ui->rightButton, &QPushButton::clicked, this, &window::move_right);

    render->setFocusPolicy(Qt::StrongFocus);
}

window::~window() {
    delete ui;
}

//permet de relier touche au joueur (à verifier car déjà présent dans render area, j'ai un doute)
void window::move_up() { render->movePlayer(0, -1); }
void window::move_down() { render->movePlayer(0, 1); }
void window::move_left() { render->movePlayer(-1, 0); }
void window::move_right() { render->movePlayer(1, 0); }
