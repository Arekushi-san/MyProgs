#pragma once

#ifndef INFO_WINDOW_HPP
#define INFO_WINDOW_HPP

#include <QWidget>

class info_window : public QWidget {
    Q_OBJECT

private:
    int score;
    int etage;
    int Nbepee;
    int life;
    int Nbcle;

public:
    explicit info_window(QWidget *parent = nullptr);

    void updateInfo(int score, int etage, int Nbepee, int life, int Nbcle);

protected:
    void paintEvent(QPaintEvent *event) override;
};

#endif
