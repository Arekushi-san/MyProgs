#pragma once

#ifndef WINDOW_HPP
#define WINDOW_HPP

#include <QMainWindow>
#include "ui_mainwindow.h"
#include "render_area.hpp"

class window : public QMainWindow {
    Q_OBJECT

public:
    window(QWidget *parent = nullptr);
    ~window();

private slots:
    void move_up();
    void move_down();
    void move_left();
    void move_right();

private:
    Ui::MainWindow *ui;
    render_area *render;
};

#endif 
