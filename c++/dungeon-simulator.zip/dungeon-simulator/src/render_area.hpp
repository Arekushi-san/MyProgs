#pragma once

#ifndef RENDER_AREA_HPP
#define RENDER_AREA_HPP

#include <QWidget>
#include "map_game.hpp"
#include "info_window.hpp"
#include "game_over_window.hpp" 

class render_area : public QWidget {
    Q_OBJECT

private:
    map_game *game;
    info_window *infoWindow;  // Fenêtre pour afficher les informations
    game_over_window *gameOverWindow;  // Fenêtre pour afficher Game Over

    bool isValidMove(int new_x, int new_y);

protected:
    void paintEvent(QPaintEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;

public:
    explicit render_area(QWidget *parent = nullptr);
    void setMaze(map_game *g);
    void movePlayer(int dx, int dy);
    void checkExit();
    void checkGameOver();  // Ajouter une méthode pour vérifier si le jeu est terminé
};

#endif
