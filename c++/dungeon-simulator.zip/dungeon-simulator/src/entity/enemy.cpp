#include "enemy.hpp"

enemy::enemy(int x, int y) : entity(x, y,false) {}



