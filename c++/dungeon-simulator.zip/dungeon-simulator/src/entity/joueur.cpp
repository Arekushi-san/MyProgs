#include "joueur.hpp"

joueur::joueur(int x, int y, int l, int s, int e, int k)
    : entity(x, y), life(l), score(s), nb_epee(e), nb_cle(k) {}

joueur::joueur(int x, int y)
    : entity(x, y), life(3), score(0), nb_epee(0), nb_cle(0) {}

// Getters
int joueur::getLife() const {
    return life;
}

int joueur::getScore() const {
    return score;
}

int joueur::getNbEpee() const {
    return nb_epee;
}

int joueur::getNb_cle() const {
    return nb_cle;
}



// Setters
void joueur::setPosition(int x, int y) {
    pos_x = x;
    pos_y = y;
}

void joueur::addNbEpee() {
    nb_epee += 1;
}

void joueur::addNb_cle() {
    nb_cle++;
}

void joueur::loseLife(){
    life=life-1;
}

void joueur::loseCle(){
    nb_cle=nb_cle-1;
}

void joueur::loseEpee(){
    nb_epee=nb_epee-1;
}

// Méthodes supplémentaires
void joueur::addScore(int plus) {
    score += plus;
}

void joueur::addLife(int l) {
    life += l;
    if (life < 0) life = 0; // Empêche d'avoir des vies négatives
}


