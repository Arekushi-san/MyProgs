#include "cle.hpp"

cle::cle(int x, int y) : entity(x, y, true) {}
