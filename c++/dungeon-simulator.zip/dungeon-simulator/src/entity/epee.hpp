#include "entity.hpp"

#pragma once

#ifndef EPEE_HPP
#define EPEE_HPP

class epee : public entity {
public:
    epee(int x, int y);
};

#endif
