#include "entity.hpp"
#pragma once

#ifndef CLE_HPP
#define CLE_HPP

class cle : public entity {
public:
    cle(int x, int y);
};

#endif