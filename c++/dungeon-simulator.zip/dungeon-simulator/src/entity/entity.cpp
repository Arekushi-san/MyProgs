#include "entity.hpp"

entity::entity(int x, int y) : pos_x(x), pos_y(y), through(true), life(1){}
entity::entity(int x, int y,bool t) : pos_x(x), pos_y(y), through(t), life(1){}

entity::entity(int x, int y,bool t, int life) : pos_x(x), pos_y(y), through(t), life(life){}

// Getters
int entity::getPosX() const {
    return pos_x;
}

int entity::getPosY() const {
    return pos_y;
}

int entity::getLife() const {
    return life;
}

bool entity::getThrough() const {
    return through;
}

// Setters
void entity::loseLife(){
    --life;
}

void entity::setThrough() {
    through=true;
}

void entity::notThrough() {
    through=false;
}