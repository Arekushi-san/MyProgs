#include "entity.hpp"
#ifndef JOUEUR_HPP
#define JOUEUR_HPP


class joueur : public entity {
    int life, score, nb_epee, nb_cle;

public:
    joueur(int x, int y);

    joueur(int x, int y, int l, int s, int e, int k );


    // Accesseurs (getters)
    int getLife() const;
    int getScore() const;
    int getNbEpee() const;
    int getNb_cle() const;

    void loseLife();
    void loseCle();
    void loseEpee();


    void setPosition(int x, int y);
    void addNbEpee();
    void addNb_cle();

    void addScore(int plus);
    void addLife(int l);
};

#endif
