#include "epee.hpp"

epee::epee(int x, int y) : entity(x, y, true) {}
