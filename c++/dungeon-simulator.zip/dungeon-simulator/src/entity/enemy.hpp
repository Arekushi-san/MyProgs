#include "entity.hpp"

#pragma once
#ifndef ENEMY_HPP
#define ENEMY_HPP

class enemy : public entity {
public:
    enemy(int x, int y);
};

#endif
