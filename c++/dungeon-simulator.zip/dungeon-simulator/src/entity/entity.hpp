#pragma once

#ifndef ENTITY_HPP
#define ENTITY_HPP



class entity {
protected:
    int pos_x, pos_y;
    bool through;
    int life;

public:
    entity(int x, int y);
    entity(int x, int y,bool t);
    entity(int x, int y,bool t, int life);
    virtual ~entity() {}  // Ajoute un destructeur virtuel, permet le dynamic cast

    bool getThrough() const;
    int getPosX() const;
    int getPosY() const;
    int getLife() const;
    void loseLife();
    void setThrough();
    void notThrough();
};

#endif
