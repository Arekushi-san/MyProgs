#include "info_window.hpp"
#include <QPainter>
#include <QFont>

info_window::info_window(QWidget *parent) : QWidget(parent), score(0), etage(1), Nbepee(0), life(3), Nbcle(0) {
    setWindowTitle("Informations du joueur");
    setFixedSize(300, 200);
}

void info_window::updateInfo(int score, int etage, int Nbepee, int life, int Nbcle) {
    this->score = score;
    this->etage = etage;
    this->Nbepee = Nbepee;
    this->life = life;
    this->Nbcle = Nbcle;
    update();  // Force le redessin
}

void info_window::paintEvent(QPaintEvent *event) {
    QPainter painter(this);

    painter.setPen(Qt::black);
    painter.setFont(QFont("Arial", 14));

    painter.drawText(20, 40, "Score: " + QString::number(score));
    painter.drawText(20, 70, "Étage: " + QString::number(etage));
    painter.drawText(20, 100, "Épées: " + QString::number(Nbepee));
    painter.drawText(20, 130, "Vies: " + QString::number(life));
    painter.drawText(20, 150, "Clés: " + QString::number(Nbcle));

}
