#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

const int WIDTH = 21;  // Largeur du labyrinthe (doit être impair)
const int HEIGHT = 21; // Hauteur du labyrinthe (doit être impair)

vector<vector<char>> maze(HEIGHT, vector<char>(WIDTH, ' ')); // Labyrinthe vide au départ

// Fonction pour afficher le labyrinthe
void printMaze() {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            cout << maze[i][j];
        }
        cout << endl;
    }
}

// Fonction pour ajouter des murs dans le labyrinthe avec des ouvertures
void addWalls(int x, int y, int width, int height, bool divideHorizontally, int passage_pos) {
    cout<<x<<","<<y<<","<<width<< ","<< height<<" "<<passage_pos<<endl;
    if (width <= 3 || height <= 3){
        cout<<"trop petit"<<endl;
        return;  // Condition d'arrêt : plus de division possible (minimum size must be at least 3x3)
    }
    cout<<height<< "taille ok"<< width <<endl;
    // Décider si on divise horizontalement ou verticalement
    

    if (divideHorizontally) {
        // Ajouter un mur horizontal
        if (y + 2 == passage_pos)
            return;
        int wy;
        do{
            wy = y + (rand() % (height - 2)) + 1;  // Position du mur (choix d'une ligne impaire)
            cout<<wy<<" "<<passage_pos<<endl;
        }while (wy == passage_pos);
        int passage_x = x + (rand() % (width - 2)) + 1;  // Position de l'ouverture (colonne impaire)
        cout<<"pourquoi"<<endl;
        // Ajouter un mur horizontal
        for (int i = 0; i < width; i++) {
            if (x + i < WIDTH && wy < HEIGHT && (x + i) != passage_x) {
                maze[wy][x + i] = '#';  // Placer un mur sauf à l'ouverture
            }
        }
        cout<<"essai"<<endl;
        printMaze();
        
        // Diviser les chambres en haut et en bas
        addWalls(x, y, width, wy - y, !divideHorizontally, passage_x);  // Partie supérieure
        addWalls(x, wy + 1, width, y + height - wy - 1, !divideHorizontally, passage_x);  // Partie inférieure
    } else {
        // Ajouter un mur vertical
        if (x + 2 == passage_pos)
            return;
        int wx;
        do{
            wx = x + (rand() % (width - 2)) + 1;  // Position du mur (choix d'une colonne impaire)
            cout<<wx<<" "<<passage_pos<<endl;
        }while (wx == passage_pos);
        int passage_y = y + (rand() % (height - 2)) + 1;  // Position de l'ouverture (ligne impaire)
        cout<<"pourquoi"<<endl;
        
        // Ajouter un mur vertical
        for (int i = 0; i < height; i++) {
            if (y + i < HEIGHT && wx < WIDTH && (y + i) != passage_y) {
                maze[y + i][wx] = '#';  // Placer un mur sauf à l'ouverture
            }
        }
        cout<<"essai"<<endl;
        printMaze();
       

        // Diviser les chambres à gauche et à droite
        addWalls(x, y, wx - x, height, !divideHorizontally, passage_y);  // Partie gauche
        addWalls(wx + 1, y, x + width - wx - 1, height, !divideHorizontally, passage_y);  // Partie droite
    }
}

// Fonction pour créer le labyrinthe
void createMaze() {
    srand(time(0));  // Initialiser le générateur aléatoire
    
    // Placer les murs extérieurs du labyrinthe
    for (int i = 0; i < WIDTH; i++) {
        maze[0][i] = '#'; // Mur supérieur
        maze[HEIGHT - 1][i] = '#'; // Mur inférieur
    }
    for (int i = 0; i < HEIGHT; i++) {
        maze[i][0] = '#'; // Mur gauche
        maze[i][WIDTH - 1] = '#'; // Mur droit
    }


    // Démarrer la division avec les dimensions entières du labyrinthe
    addWalls(1, 1, WIDTH - 2, HEIGHT - 2, bool(rand() % 2), -1);

    // Créer les points d'entrée et de sortie
    maze[1][0] = 'S';  // Point de départ
    maze[HEIGHT - 2][WIDTH - 1] = 'E'; // Point de sortie
}

int main() {
    createMaze();
    printMaze();
    
    return 0;
}
