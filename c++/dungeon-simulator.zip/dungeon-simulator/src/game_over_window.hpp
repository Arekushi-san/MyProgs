#pragma once

#ifndef GAME_OVER_WINDOW_HPP
#define GAME_OVER_WINDOW_HPP

#include <QWidget>

class game_over_window : public QWidget {
    Q_OBJECT

public:
    explicit game_over_window(QWidget *parent = nullptr);

protected:
    void paintEvent(QPaintEvent *event) override;
};

#endif
