#pragma once

#ifndef MAP_GAME_HPP
#define MAP_GAME_HPP

#include <vector>
#include "entity/entity.hpp"
#include "entity/joueur.hpp"

class map_game {
public:
    map_game(int width, int height);
    ~map_game();

    void init();
    void generateMaze();
    void ajout_obj();

    std::vector<std::vector<entity*>> getMaze() const;
    int get_entreex() const;
    int get_entreey() const;
    int get_sortiex() const;
    int get_sortiey() const;
    int get_etage() const;
    void add_etage();

    void modifCase(int x, int y);

    joueur* getPlayer() const;  // Récupérer le joueur

private:
    int size_x, size_y;
    std::vector<std::vector<entity*>> maze;
    joueur* player;  // Pointeur vers le joueur
    int etage;

    void addWalls(int x, int y, int width, int height, bool divideHorizontally, int passage_pos);
};

#endif // MAP_GAME_HPP
