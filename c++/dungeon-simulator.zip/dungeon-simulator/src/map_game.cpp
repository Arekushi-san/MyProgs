#include <iostream>
#include <cstdlib>
#include <ctime>
#include <random>

#include "map_game.hpp"

#include "bloc/bloc.hpp"
#include "bloc/chemin.hpp"
#include "bloc/entree.hpp"
#include "bloc/hole.hpp"
#include "bloc/mur.hpp"
#include "bloc/porte.hpp"
#include "bloc/sortie.hpp"
#include "entity/enemy.hpp"
#include "entity/joueur.hpp"
#include "entity/cle.hpp"
#include "entity/epee.hpp"



map_game::map_game(int width, int height) : size_x(width), size_y(height), etage(1) {
    maze.resize(size_x, std::vector<entity*>(size_y, nullptr));  // Initialisation de la map

    // Initialisation du joueur à l'entrée
    player = new joueur(get_entreex(), get_entreey());

    generateMaze();  // Génération du labyrinthe
}

map_game::~map_game() {
    // Libérer la mémoire de la carte
    for (int x = 0; x < size_x; x++) {
        for (int y = 0; y < size_y; y++) {
            delete maze[x][y];
        }
    }

    // Libérer la mémoire du joueur
    delete player;
}

void map_game::init() {
    generateMaze();
}

std::vector<std::vector<entity*>> map_game::getMaze() const {
    return maze;
}

int map_game::get_entreex() const {
    return 0; // x de l'entrée
}

int map_game::get_entreey() const {
    return 1; // y de l'entrée
}

int map_game::get_sortiex() const {
    return size_x - 1; // x de la sortie
}

int map_game::get_sortiey() const {
    return size_y - 2; // y de la sortie
}

// Getter pour accéder au joueur
joueur* map_game::getPlayer() const {
    return player;  // Retourne l'objet joueur
}

int map_game::get_etage() const {
    return etage;
}

void map_game::add_etage() {
    etage++;
}

void map_game::modifCase(int x,int y){
    delete maze[x][y];
    maze[x][y]=new chemin(x, y); 
}


// Génération du labyrinthe
void map_game::generateMaze() {
    srand(time(0));

    // Remplir le labyrinthe avec des chemins
    for (int x = 0; x < size_x; x++) {
        for (int y = 0; y < size_y; y++) {
            maze[x][y] = new chemin(x, y);
        }
    }

    // Création des bordures (murs)
    for (int i = 0; i < size_x; i++) {
        maze[i][0] = new mur(i, 0);
        maze[i][size_y - 1] = new mur(i, size_y - 1);
    }
    for (int i = 0; i < size_y; i++) {
        maze[0][i] = new mur(0, i);
        maze[size_x - 1][i] = new mur(size_x - 1, i);
    }

    // Génération du labyrinthe intérieur
    addWalls(1, 1, size_x - 2, size_y - 2, rand() % 2, -1);

    // Définition de l'entrée et de la sortie
    delete maze[0][1];  
    maze[0][1] = new entree(0, 1);

    delete maze[size_x - 1][size_y - 2];  
    maze[size_x - 1][size_y - 2] = new sortie(size_x - 1, size_y - 2);

    // Placer le joueur à l'entrée
    player->setPosition(get_entreex(), get_entreey());

    // Retirer les blocs bloquants
    for (int x = 1; x < size_x - 1; x++) {
        for (int y = 1; y < size_y - 1; y++) {
            bool mur_bas_gauche = dynamic_cast<mur*>(maze[x-1][y+1]);
            bool mur_bas_droite = dynamic_cast<mur*>(maze[x+1][y+1]);
            bool mur_haut_gauche = dynamic_cast<mur*>(maze[x-1][y-1]);
            bool mur_haut_droite = dynamic_cast<mur*>(maze[x+1][y-1]);

            int nb_murs = mur_bas_gauche + mur_bas_droite + mur_haut_gauche + mur_haut_droite;

            bool chemin_gauche = dynamic_cast<chemin*>(maze[x-1][y]);
            bool chemin_droite = dynamic_cast<chemin*>(maze[x+1][y]);
            bool chemin_haut = dynamic_cast<chemin*>(maze[x][y-1]);
            bool chemin_bas = dynamic_cast<chemin*>(maze[x][y+1]);

            int nb_chemin = chemin_gauche + chemin_droite + chemin_haut + chemin_bas;

            if ((nb_murs >=2) && nb_chemin >= 3) {
                maze[x][y] = new chemin(x, y);
            }
        }
    }
}

// Génération des murs internes
void map_game::addWalls(int x, int y, int width, int height, bool divideHorizontally, int passage_pos) {
    if (width <= 3 || height <= 3) return;

    if (divideHorizontally) {
        int wx;
        do { wx = x + (rand() % (width - 2)) + 1; } while (wx == passage_pos);
        int passage_y = y + (rand() % (height - 2)) + 1;

        for (int i = 0; i < height; i++) {
            if ((y + i) != passage_y) {
                delete maze[wx][y + i];
                maze[wx][y + i] = new mur(wx, y + i);
            }
        }

        addWalls(x, y, wx - x, height, !divideHorizontally, passage_y);
        addWalls(wx + 1, y, x + width - wx - 1, height, !divideHorizontally, passage_y);
    } else {
        int wy;
        do { wy = y + (rand() % (height - 2)) + 1; } while (wy == passage_pos);
        int passage_x = x + (rand() % (width - 2)) + 1;

        for (int i = 0; i < width; i++) {
            if ((x + i) != passage_x) {
                delete maze[x + i][wy];
                maze[x + i][wy] = new mur(x + i, wy);
            }
        }

        addWalls(x, y, width, wy - y, !divideHorizontally, passage_x);
        addWalls(x, wy + 1, width, y + height - wy - 1, !divideHorizontally, passage_x);
    }
}

void map_game::ajout_obj(){

    //enemy
    srand(time(0));
    int ENNX = rand() % (size_x - 6) + 4;
    int ENNY = rand() % (size_y - 6) + 4;

    for(int x = ENNX - 1; x <= ENNX + 1; x++) {
        for(int y = ENNY - 1; y <= ENNY + 1; y++) {
            delete maze[x][y];
            maze[x][y] = new chemin(x, y);
        }
    }

    maze[ENNX][ENNY] = new enemy(ENNX, ENNY);

    //porte
    int alea = rand() % (100)+1;
    if (alea>50){
        for(int i=get_sortiex()-2;i<=get_sortiex();i++){
            for(int j=get_sortiex()-2;j<=get_sortiey();j++){
                if( (i==get_sortiex()-1 && j>=get_sortiey()-1) || (i==get_sortiex()-1 && j>=get_sortiey()) ){
                    delete maze[i][j];
                    maze[i][j] = new mur(i, j);
                }
                if(i==get_sortiex() && j==get_sortiey()-1){
                    delete maze[i][j];
                    maze[i][j] = new porte(i, j);
                }
                else if(i!=get_sortiex() && j!=get_sortiey()){
                    delete maze[i][j];
                    maze[i][j] = new chemin(i, j);
                }
            }
        }
    }
    //cle
    int aleaclex=rand() %(size_x-3);
    int aleacley=rand() %(size_y-3);
    int yp=0;
    for (int x = aleaclex; x < size_x - 1; x++) {
        for (int y = aleacley; y < size_y - 1; y++) {
            if(dynamic_cast<chemin*>(maze[x][y])){
                delete maze[x][y];
                maze[x][y]= new cle(x,y);
                yp=y;
                break;
                
            }
        }
        if(dynamic_cast<cle*>(maze[x][yp])){
            break;
        }
    }

    //cle
    int aleaepeex=rand() %(size_x-3);
    int aleaepeey=rand() %(size_y-3);
    yp=0;
    for (int x = aleaepeex; x < size_x - 1; x++) {
        for (int y = aleaepeey; y < size_y - 1; y++) {
            if(dynamic_cast<chemin*>(maze[x][y])){
                delete maze[x][y];
                maze[x][y]= new epee(x,y);
                yp=y;
                break;
            }
        }
        if(dynamic_cast<epee*>(maze[x][yp])){
            break;
        }
    }

    //Trou
    int aleatroux=rand() %(size_x-3);
    int aleatrouy=rand() %(size_y-3);
    yp=0;
    for (int x = aleatroux; x < size_x - 1; x++) {
        for (int y = aleatrouy; y < size_y - 1; y++) {
            if(dynamic_cast<chemin*>(maze[x][y])){
                delete maze[x][y];
                maze[x][y]= new hole(x,y);
                yp=y;
                break;
            }
        }
        if(dynamic_cast<hole*>(maze[x][yp])){
            break;
        }
    }
}
