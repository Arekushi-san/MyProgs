// Chemin.cpp
#include "hole.hpp"

hole::hole(int x, int y) : bloc(x, y, true) {}
