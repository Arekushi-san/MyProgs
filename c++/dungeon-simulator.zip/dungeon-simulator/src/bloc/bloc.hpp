#include "../entity/entity.hpp"

#pragma once

#ifndef BLOC_HPP
#define BLOC_HPP

class bloc : public entity {

public:
    bloc(int x, int y, bool t);

};

#endif
