#include "entree.hpp"

entree::entree(int x, int y) : bloc(x, y, true) {}
