#include "bloc.hpp"
#pragma once

#ifndef SORTIE_HPP
#define SORTIE_HPP

class sortie : public bloc {
public:
    sortie(int x, int y);
};

#endif
