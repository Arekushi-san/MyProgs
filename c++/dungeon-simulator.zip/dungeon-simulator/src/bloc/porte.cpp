#include "porte.hpp"

porte::porte(int x, int y) : bloc(x, y, false) {}
