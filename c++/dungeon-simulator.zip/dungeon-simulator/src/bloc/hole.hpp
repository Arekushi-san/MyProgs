#include "bloc.hpp"
#pragma once

#ifndef HOLE_HPP
#define HOLE_HPP

class hole : public bloc {
public:
    hole(int x, int y);
};

#endif