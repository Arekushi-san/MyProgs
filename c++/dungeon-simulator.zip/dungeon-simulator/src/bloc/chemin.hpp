#include "bloc.hpp"
#pragma once

#ifndef CHEMIN_HPP
#define CHEMIN_HPP

class chemin : public bloc {
public:
    chemin(int x, int y);
};

#endif