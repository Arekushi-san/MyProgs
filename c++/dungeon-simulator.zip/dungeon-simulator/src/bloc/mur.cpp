#include "mur.hpp"

mur::mur(int x, int y) : bloc(x, y, false) {}
