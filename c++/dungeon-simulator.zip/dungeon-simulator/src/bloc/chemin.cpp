// Chemin.cpp
#include "chemin.hpp"

chemin::chemin(int x, int y) : bloc(x, y, true) {}
