#include "sortie.hpp"

sortie::sortie(int x, int y) : bloc(x, y, true) {}
