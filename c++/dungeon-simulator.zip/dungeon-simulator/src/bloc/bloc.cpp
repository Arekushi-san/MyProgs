#include "bloc.hpp"

bloc::bloc(int x, int y, bool t) : entity(x,y,t) {}



