#include "bloc.hpp"

#pragma once
#ifndef PORTE_HPP
#define PORTE_HPP

class porte : public bloc {
public:
    porte(int x, int y);
};

#endif
