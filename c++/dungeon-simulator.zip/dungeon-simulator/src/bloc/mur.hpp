#include "bloc.hpp"

#pragma once

#ifndef MUR_HPP
#define MUR_HPP

class mur : public bloc {
public:
    mur(int x, int y);
};

#endif

