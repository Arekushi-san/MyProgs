#include "bloc.hpp"

#pragma once

#ifndef ENTREE_HPP
#define ENTREE_HPP


class entree : public bloc {
public:
    entree(int x, int y);
};

#endif
