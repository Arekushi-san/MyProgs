//-----------------------------------------------------------------------------
// TP1_BSE.c
//-----------------------------------------------------------------------------
// AUTH: 
// DATE: 
//
// Target: C8051F02x
// Tool chain: KEIL Microvision5
//
//-----------------------------------------------------------------------------
// D�clarations Registres et Bits de l'espace SFR
#include "intrins.h"
#include<c8051F020.h>
#include<c8051F020_SFR16.h>
#include<TP1_BSE_Lib_Config_Globale.h>
#include<TP1_BSE_Lib_Divers.h>

#define LED_ON 1
#define LED_OFF 0

#define BP_ON 0
#define BP_OFF 1

sbit LED = P1^6;  // LED
sbit BP = P3^7; // Bouton
bit ETAT_LED = 1; // A 1 si la LED clignote
bit ACK_BP; // Correspond � l'�tat du bouton de la boucle d'avant

sbit VISU_INT7_START = P2^0;

bit VISU_INT7_END;
bit VISU_INT7_WIDTH;
//------------------------------------------------------------------------------------
// Function Prototypes

//------------------------------------------------------------------------------------


/*
void Config_INT7_Ext(void)
{
	
}
*/




void INT7(void) interrupt 19 {
	VISU_INT7_START = 1;
	VISU_INT7_START = 0;
	VISU_INT7_WIDTH = 1;
	
	
	
	ETAT_LED = ~ETAT_LED;
	P3IF &= ~(1<<7); // RAZ INT7 Pending Flag (P3IF page 177) // Pour quitter interruption

	
	VISU_INT7_END = 1;
	VISU_INT7_END = 0;
	VISU_INT7_WIDTH = 0;
	/*
	if (ACK_BP == BP_OFF) { 
		 ACK_BP = BP_ON;
		 
	 
	 } else {
		 ACK_BP = BP_OFF;
		 
	 } */
}

//------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------
void main (void) {
				
				//P3IF &= ~(1<<7); // RAZ INT7 Pending Flag (P3IF page 177)
				P3IF &= ~(1<<3); // D�clenchement INT7 sur front descendant
				EIP2 |= (1<<5); // Gestion priorit�
				EIE2 |= (1<<5); //EX7 = 1 Autorisation de l'interruption INT7
				IE |= (1<<7);
	
	      Init_Device();
				EA = 1;
	
				P3MDOUT &= ~(1<<7);
				BP = 1;
	
				VISU_INT7_END = P6&(1<<0)==(1<<0);
				VISU_INT7_WIDTH = P6&(1<<1)==(1<<1);
	
        while(1)
        {  	 /* // ------------ Etape 1 ----------------------
						 if (BP == BP_ON && ACK_BP == BP_OFF) { 
							 ACK_BP = BP_ON;
							 ETAT_LED = !ETAT_LED;
						 
						 } else if (BP == BP_OFF) {
							 ACK_BP = BP_OFF;
							 
						 } 
						 if (ETAT_LED == 1) {
							 LED = LED_ON;
							 Software_Delay(2); // Temporisation 20ms
							 LED = LED_OFF;
							 Software_Delay(10); // Temporisation 100ms
						 } else {
							 LED = LED_OFF;
							 
						 }*/

					   			 
					// ------------ Etape 2 ----------------------
					
					if (ETAT_LED == 1) {
							 LED = LED_ON;
							 Software_Delay(2); // Temporisation 20ms
							 LED = LED_OFF;
							 Software_Delay(10); // Temporisation 100ms
						 } else {
							 LED = LED_OFF;
							 
						 }
        }						               	
			}
//*****************************************************************************	 
