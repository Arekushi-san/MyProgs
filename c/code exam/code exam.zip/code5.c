#include <stdio.h>
#include <string.h>

char lire_fichier(char *nom_de_fichier, int *CaMoLi, char *motlepluslong) {
    // Ouverture du fichier
    FILE *fichier = fopen(nom_de_fichier, "r");

    // Vérification de la présence du fichier
    if (fichier == NULL) {
        printf("Erreur lors de l'ouverture du fichier\n");
        return 1;
    }

    char c;
    char mot[100] = ""; // Mot en cours
    int index = 0;      // Indice pour mot
    int comptemax = 0;

    // Initialisation des compteurs
    CaMoLi[0] = 0; // Nombre de caractères
    CaMoLi[1] = 0; // Nombre de mots
    CaMoLi[2] = 0; // Nombre de lignes

    printf("Contenu du fichier %s :\n", nom_de_fichier);

    // Lecture du fichier
    while ((c = fgetc(fichier)) != EOF) {
        CaMoLi[0]++; // Compter chaque caractère
        printf("%c", c);

        if (c == ' ' || c == ',' || c == '.' || c == '\n') {
            if (index > 0) { // Si un mot est en cours
                CaMoLi[1]++; // Compter le mot
                if (index > comptemax) {
                    comptemax = index; // Longueur maximale
                    strcpy(motlepluslong, mot); // Mot le plus long
                }
                index = 0; // Réinitialiser pour le prochain mot
            }
            if (c == '\n') {
                CaMoLi[2]++; // Compter la ligne
            }
        } else {
            mot[index++] = c; // Ajouter le caractère au mot
            mot[index] = '\0'; // Terminer le mot
        }
    }

    // Fermer le fichier
    fclose(fichier);

    return 0;
}

int main() {
    char txt[60];
    int nbCarMotLigne[3] = {0, 0, 0};
    char motlepluslong[100] = ""; // Mot le plus long

    // Saisie par l'utilisateur du nom du fichier
    printf("\nQuel est le nom du fichier à utiliser : ");
    scanf(" %s", txt);

    lire_fichier(txt, nbCarMotLigne, motlepluslong);

    printf("\nNombre de caractères : %d\n", nbCarMotLigne[0]);
    printf("Nombre de mots : %d\n", nbCarMotLigne[1]);
    printf("Nombre de lignes : %d\n", nbCarMotLigne[2]);
    printf("Mot le plus long : %s\n", motlepluslong);

    return 0;
}
