#include <stdio.h>

   int valeur = 1000;

 

   void modifierValeur(int *valeur) {

       *valeur = 3000;

       valeur += 1;

       *valeur = 3500; 

       printf("Valeur dans modifierValeur: %d\n", *valeur);

   }

 

   int main() {

       int valeur = 2000;

       int *p = &valeur;

       *p *= 2;

       {

           int valeur = 4000;

           int *q = &valeur;

           *q -= 1000;

           printf("Valeur dans le bloc interne de main: %d\n", *q);

       }

       modifierValeur(p);

       printf("Valeur dans main: %d\n", valeur);

       printf("Valeur globale: %d\n", valeur);

       return 0;

   }
/*
gcc -Wall -Wextra -o code code3.c
./code

*/