// Fichier: couleur_compteur.c
// TP1 Exercice 3.7
// VENET ALEXIS et RODDE THEOPHILE
// le 30/09/2024

#include <stdio.h>

int main() {

    //Declaration des tableaux
    int Tableau[8][8]={{2,4,3,5,6,8,10,12},
                        {2,4,3,5,6,8,10,12},
                        {2,4,3,5,6,8,10,12},
                        {2,4,3,5,6,8,10,12}};

    //Declaration des pointeurs
    int *i_ptr=(int *)&(*Tableau);
    int *j_ptr=&(*i_ptr);
    
    int min=13;
    int max=0;
    int somme=0;
    int nb_val=0;
    int val=0;
    printf("\nTableau :\n");
    printf("```\n");

    //Boucle for pour afficher Tableau
    for(int i=0;i<3;i++){
        
        for(int j=0;j<8;j++){
            val=*j_ptr;
            printf("%i ",val);
            if(val<min){
                min=val;
            }
            if(val>max){
                max=val;
            }
            nb_val+=1;
            j_ptr+=1;
            somme+=val;
        }
        printf("\n");
        i_ptr+=1;
        j_ptr=&(*i_ptr);
        
    }
    printf("\n```\n\n");
    printf("minimum : %i\n",min);
    printf("maximum : %i\n",max);
    printf("somme : %i\n",somme);
    printf("moyenne : %.3f\n",(float)(somme/nb_val));


    return 0;
}

/*

gcc -Wall -Wextra -o code code2.c
./code

*/