// Fichier: couleur_compteur.c
// TP1 Exercice 3.7
// VENET ALEXIS et RODDE THEOPHILE
// le 30/09/2024

#include <stdio.h>
int pente(float x1,float y1,float x2,float y2){
    if(x2==x1){
        if(y2==y1){
            printf("point1 et point2 sont au meme endroit.\n");
            return 0;
        }
        else{
            printf("pente infinie\n");
            return 0;
        }
    }
    float Pente_Val=(y2-y1)/(x2-x1);
    printf("%f\n",Pente_Val);
    return 0;

}


int main() {

    //creation de la structure Couleurs
    struct Spoint2D{
        float x;
        float y;
    };

    struct Spoint2D point1;
    point1.x=1;
    point1.y=1;
    struct Spoint2D point2;
    point2.x=2;
    point2.y=4;
    printf("x1=%f,y1=%f,x2=%f,y2=%f\n",point1.x,point1.y,point2.x,point2.y);
    pente(point1.x,point1.y,point2.x,point2.y);

    return 0;
}

/*

gcc -Wall -Wextra -o code code.c
./code

*/