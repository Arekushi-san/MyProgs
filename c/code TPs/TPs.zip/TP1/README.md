On a realise l'ensemble des exercices du TP1

bibliotheque utilise :
#include <stdio.h>
#include <math.h>
#include <string.h>

Groupe A

niveau de difficulté : facile

Commentaires :

    binaire.c :
    On aurait pu utiliser un masque pour l'exercice binaire.c, avec les operations bit a bit.
    On a du utiliser un convertisseur binaire en ligne pour verifier nos resultats.
