// Fichier: calculs.c
// TP1 Exercice 1.8
// VENET ALEXIS et RODDE THEOPHILE
// le 16/09/2024

#include <stdio.h>

int main() {

    //declaration des varibales
    int num1=32;
    int num2=64+32;
    char op='&';

    //switch qui permet de selectionner le calcul a realiser en fonction de op
    switch(op){
        
        case '+':
            printf("num1 + num2 : %d\n",num1+num2);
            break;

        case '-':
            printf("num1 - num2 : %d\n",num1-num2);
            break;

        case '*':
            printf("num1 * num2 : %d\n",num1*num2);
            break;

        case '/':
            printf("num1 / num2 : %f\n",(float)num1/num2);
            break;

        case '%':
            printf("num1 Modulo num2 : %d\n",num1%num2);
            break;

        case '&':
            printf("num1 & num2 : %d\n",num1&num2);
            break;

        case '|':
            printf("num1 | num2 : %d\n",num1|num2);
            break;

        case '~':
            printf("~num1 : %d\n",~num1);
            printf("~num2 : %d\n",~num2);
            break;

    }

    return 0;
}

/*

gcc -Wall -Wextra -o calculs calculs.c
./calculs

*/
