// Fichier: binaire.c
// TP1 Exercice 1.9
// VENET ALEXIS et RODDE THEOPHILE
// le 16/09/2024

#include <stdio.h>
#include <math.h>

int main() {
    
    //declaration des variables
    int num=67;
    int a;
    int i;
    int j;
    int tableau[32];

    //boucle for permettant de transformer num en nombre binaire
    for(i=31;(i>=0)&(num>1);i--) {
        
        a=num%2;
        if(a){
            tableau[i]=1;
        }
        else{
            tableau[i]=0;
        }

        num=num/2;
    }

    //permet de recuperer la derniere valeur que prend num
    tableau[i]=num;

    //permet l'affichage du tableau j dans le bon ordre
    for(j=i;j<=31;j++){
        printf("%i",tableau[j]);
    }

    printf("\n");

    return 0;
}

/*

gcc -Wall -Wextra -o binaire binaire.c
./binaire

*/