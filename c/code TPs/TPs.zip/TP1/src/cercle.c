// Fichier: cercle.c
// TP1 Exercice 1.2
// VENET ALEXIS et RODDE THEOPHILE
// le 16/09/2024

#include <stdio.h>
#include <math.h>


int main() {

    //Declaration des variables rayon, aire et perimetre
    float rayon=2;
    float aire = M_PI * rayon * rayon;
    float perimetre = 2 * M_PI * rayon;
    
    //affichage des valeurs des variables aire et perimetre
    printf("Air du cercle : %f\n",aire);
    printf("Perimetre du cercle : %f\n",perimetre);
    
    return 0;
}

/*
gcc -o cercle cercle.c -lm
./cercle

ou

gcc -Wall -Wextra -o cercle cercle.c -lm
./cercle

*/