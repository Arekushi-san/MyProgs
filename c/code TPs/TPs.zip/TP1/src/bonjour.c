// Fichier: bonjour.c
// TP1 Exercice 1.1
// VENET ALEXIS et RODDE THEOPHILE
// le 16/09/2024

#include <stdio.h>

int main() {

    printf("Bonjour le Monde!\n");
    return 0;
    
}

/*
gcc bonjour.c
./a.out

gcc -o bonjour bonjour.c
./bonjour

gcc -Wall -Wextra -o bonjour bonjour.c
./bonjour
*/
