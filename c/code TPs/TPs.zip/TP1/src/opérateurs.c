// Fichier: opérateurs.c
// TP1 Exercice 1.5
// VENET ALEXIS et RODDE THEOPHILE
// le 16/09/2024

#include <stdio.h>


int main() {

    //declaration de a et b
    int a = 16;
    int b=3;

    //addition, soustraction, multiplication et division de a avec b
    float Resultat1 = a+b;
    printf("a+b : %f\n",Resultat1);

    float Resultat2 = a-b;
    printf("a-b : %f\n",Resultat2);

    float Resultat3 = a*b;
    printf("a*b : %f\n",Resultat3);

    float Resultat4 = (float)a/b;
    printf("a/b : %f\n",Resultat4);

    float Resultat5 = a % b;
    printf("a modulo b : %f\n",Resultat5);

    //verification a==b
    int Resultat6 = a==b;
    if (Resultat6) {
        printf("a==b : True\n");
    }
    else{
        printf("a==b : False\n");
    }

    //verification a>=b
    int Resultat7 = a>=b;
    if (Resultat7) {
        printf("a>=b : True\n");
    }
    else{
        printf("a>=b : False\n");
    }

    return 0;
}

/*

gcc -Wall -Wextra -o opérateurs opérateurs.c
./opérateurs

*/