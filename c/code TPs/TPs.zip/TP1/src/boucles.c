// Fichier: boucles.c
// TP1 Exercice 1.6
// VENET ALEXIS et RODDE THEOPHILE
// le 16/09/2024

#include <stdio.h>

int main() {

    //declaration de la variable a(commande du switch) et du compteur
    int a=2;
    float compteur=5;

    //condition pour arreter le programme si compteur>10
    if(compteur>10){
        printf("Compeur>10, arret du programe\n");
        return 0;
    }

    //switch :  si a==1, realisation de l'exercice avec boucle for
    //          si a==2, realisation de l'exercice avec boucle while
    switch(a){
        int i;int j;

        case 1:
            printf("Boucle for\n");

            //boucle for permettant de parcourir les lignes
            for(i=1;i<=compteur;i++){

                //boucle for permettant de parcourir les colonnes
                for(j=1;j<=i;j++){
                    
                    if((j==1) || (j==i) || (i==compteur)){
                        printf("* ");
                    }
                    else{
                        printf("# ");
                    }
                }
                printf("\n");   
            }
            break;

        case 2:
            printf("Boucle while\n");
            i=1;

            //boucle while permettant de parcourir les lignes
            while(i<=compteur){
                j=1;

                //boucle while permettant de parcourir les colonnes
                while(j<=i){
                    if((j==1) || (j==i) || (i==compteur)){
                        printf("* ");
                    }
                    else{
                        printf("# ");
                    }
                    j++;
                }
                i++;
                printf("\n");
                }
            break;
    }   

return 0;
}
/*

gcc -Wall -Wextra -o boucles boucles.c
./boucles

*/
       
