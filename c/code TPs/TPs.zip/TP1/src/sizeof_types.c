// Fichier: sizeof_types.c
// TP1 Exercice 1.3
// VENET ALEXIS et RODDE THEOPHILE
// le 16/09/2024

#include <stdio.h>

int main() {

    //`char`
    printf("signed char : %lu\n",sizeof (signed char));
    printf("unsigned char : %lu\n\n",sizeof (unsigned char));

    //`short`
    printf("signed short : %lu\n",sizeof (signed short));
    printf("unsigned short : %lu\n\n",sizeof (unsigned short));

    //`int`
    printf("signed int : %lu\n",sizeof (signed int));
    printf("unsigned int : %lu\n\n",sizeof (unsigned int));

    //`long int`
    printf("signed long int : %lu\n",sizeof (signed long int));
    printf("unsigned long int : %lu\n\n",sizeof (unsigned long int));

    //`long long int`
    printf("signed char : %lu\n",sizeof (signed long int));
    printf("unsigned char : %lu\n\n",sizeof (long int));

    //NO UNSIGNED & SIGNED
    //`float`
    printf("char : %lu\n",sizeof (float));

    //`double`
    printf("double : %lu\n",sizeof (double));

    //`long double`
    printf("long double : %lu\n",sizeof (long double));

    return 0;
}

/*

gcc -Wall -Wextra -o sizeof_types sizeof_types.c
./sizeof_types

Les variables signed et unsigned ont le même nombre d'octets assignés

*/