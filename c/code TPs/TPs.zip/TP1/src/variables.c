// Fichier: variables.c
// TP1 Exercice 1.4
// VENET ALEXIS et RODDE THEOPHILE
// le 16/09/2024

#include <stdio.h>

int main() {


    //'char'
    char Char = 'h';
    printf("char = %c\n",Char);

    unsigned char UChar = 'h';
    printf("char = %c\n",UChar);

    //'short'
    short Short = 1;
    printf("char = %hd\n",Short);

    unsigned short UShort = 1;
    printf("char = %hu\n",UShort);

    //'int'
    int Int = 1;
    printf("char = %d\n",Int);

    unsigned int UInt = 1;
    printf("char = %u\n",UInt);

    //'long int'
    long int LInt = 1;
    printf("char = %ld\n",LInt);

    unsigned long int ULInt = 1;
    printf("char = %lu\n",ULInt);


    //'long long int'
    long long int LLInt = 1;
    printf("char = %lld\n",LLInt);

    unsigned long long int ULLInt = 1;
    printf("char = %llu\n",ULLInt);

    //'float'
    float Float = 1;
    printf("char = %f\n",Float);


    //'double'
    double Double = 1;
    printf("char = %g\n",Double);


    //'long double'
    long double LDouble = 1;
    printf("char = %Lg\n",LDouble);


    return 0;
}

/*

gcc -Wall -Wextra -o variables variables.c
./variables

*/