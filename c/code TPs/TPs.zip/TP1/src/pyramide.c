// Fichier: pyramide.c
// TP1 Exercice 1.10
// VENET ALEXIS et RODDE THEOPHILE
// le 16/09/2024

#include <stdio.h>

int main() {

    //declaration des variables des boucles, du compteur et de l'operateur
    int i;
    int j;
    int k;
    int compteur=9;
    int op=1;

    //boucle permettant d'effectuer chaque ligne
    for(i=1;i<=compteur;i++){
        op=1;
        
        //boucle pour centrer l'affichage de la pyramide
        for(k=0;k<compteur-i;k++){
            printf(" ");
        }
        
        //boucle pour afficher tous les chiffres de la ligne
        for(j=1;(j<=i)&(j>0);){
            printf("%i",j);
            if(j==i){op=op*(-1);}
            j=j+op;
        }
        
        printf("\n");
    }

return 0;
}

/*

gcc -Wall -Wextra -o pyramide pyramide.c
./pyramide

la variable op permet de soustraire 1 au lieu d'ajouter 1 lorsque nous avons atteint la valeur
maximal, le milieu de la pyramide
*/