// Fichier: conditions.c
// TP1 Exercice 1.7
// VENET ALEXIS et RODDE THEOPHILE
// le 16/09/2024

#include <stdio.h>

int main() {

    //declaration des variables
    int i;
    int somme=0;

    //boucle for 
    for(i=1;i<=1000;i++) {

        //condition qui indique que les multiples de 5 ou 7 qui ne sont pas multiple de 11
        //sont ajoutes a la somme
        if( (((i % 5)==0)||((i%7)==0)) && !((i%11)==0) ) {
            somme+=i;
            printf("valI :%d\n",i);
        }
        
        //affichage de la somme depasse 5000 et arret du programme 
        if(somme>5000){
            printf("la somme dépasse 5 000\n");
            printf("somme total : %d\n",somme);
            return 0;
        }
    }

    //affichage de la somme total
    printf("somme total :%i\n",somme);

    return 0;
}

/*

gcc -Wall -Wextra -o conditions conditions.c
./conditions

*/