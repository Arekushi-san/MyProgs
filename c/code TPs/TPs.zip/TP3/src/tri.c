// Fichier: tri.c
// TP1 Exercice 3.3
// VENET ALEXIS et RODDE THEOPHILE
// le 29/09/2024

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    
    //initialisation de srand
    srand(time(NULL));

    //Declaration des variables
    int tableau[100];
    int meme;
    int i;
    int j;

    printf("\nTableau avant tri :\n'''\n[");
    //boucle for permettant de remplir tableau avec des nombres de -50 a 50
    for(i=0;i<100;i++){
        tableau[i]=(rand() % (101))-50;
        printf("%i ",tableau[i]);
        if(i!=99){
            printf(",");
        }
    }
    printf("]\n\n");

    //boucle for permettant de trier les elements par insertion
    for (i=0;i<100;i++){
        meme= tableau[i];
        
        //boucle for permettant de deplacer a droite le nombre tant que celui ci est plus petit 
        for(j=i-1;j>=0 && tableau[j]>meme;j--){
            tableau[j+1]=tableau[j];
        }
        tableau[j+1]=meme;

    }

    printf("\nTableau après tri :\n'''\n[");
    //affichage du tableau
    for(i=0;i<100;i++){
        printf("%i ",tableau[i]);
        if(i!=99){
            printf(",");
        }
    }
    printf("]\n\n");

    return 0;
}

/*

gcc -Wall -Wextra -o tri tri.c
./tri

*/