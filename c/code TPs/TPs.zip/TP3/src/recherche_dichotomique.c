// Fichier: recherche_dichotomique.c
// TP1 Exercice 3.5
// VENET ALEXIS et RODDE THEOPHILE
// le 29/09/2024

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    
    //initialisation de srand
    srand(time(NULL));

    //Declaration des variables
    int tableau[100];
    int chercher;
    int meme;
    int max=99;
    int min=0;
    int j=0;
    int trouve=0;

    //boucle for permettant de remplir tableau avec des nombres de -50 a 50
    for(int i=0;i<100;i++){
        tableau[i]=(rand() % (101))-50;
    }

    //boucle for permettant de trier les elements par insertion
    for(int i=0;i<100;i++){
        meme= tableau[i];
        
        //boucle for permettant de deplacer a droite le nombre tant que celui ci est plus petit 
        for(j=i-1;j>=0 && tableau[j]>meme;j--){
            tableau[j+1]=tableau[j];
        }
        tableau[j+1]=meme;
        
    }

    printf("\nTableau :\n");
    //boucle for pour affichage du tableau trie
    for(int i=0;i<100;i++){
        printf("%i ",tableau[i]);
        if(i%10==0 && i!=0){
            printf("\n");
        }
    }
    //pour lire plus facilement le tableau, retour a la ligne toutes les 10 valeurs pour l'affichage

    //saisi de la valeur a rechercher par l'utilisateur
    printf("\n\nEntrez l'entier que vous souhaitez chercher : ");
    scanf("%i", &chercher);

    
    //boucle while realisant la recherche dichotomique.
    while(min<=max){
        j=(max+min)/2;
        
        if(tableau[j]==chercher){
            trouve=1;
            break;
        }

        if(tableau[j]<chercher){
            min=j+1;
        }

        else{
            max=j-1;
        }
        
    }

    if(trouve){
        printf("\nResultat : entier present\n");
    }
    else{
        printf("\nResultat : entier non present\n");
    }
    return 0;
}

/*

gcc -Wall -Wextra -o recherche_dichotomique recherche_dichotomique.c
./recherche_dichotomique

*/