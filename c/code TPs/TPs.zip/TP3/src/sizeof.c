// Fichier: sizeof.c
// TP1 Exercice 3.1
// VENET ALEXIS et RODDE THEOPHILE
// le 28/09/2024

#include <stdio.h>

int main() {

    //affichage de la taille des variables demandees 
    printf("\n```\n");
    printf("La taille de int est : %li octets\n",sizeof(int));
    printf("La taille de int* est : %li octets\n",sizeof(int*));
    printf("La taille de int** est : %li octets\n",sizeof(int**));
    printf("La taille de char* est : %li octets\n",sizeof(char*));
    printf("La taille de char** est : %li octets\n",sizeof(char**));
    printf("La taille de char*** est : %li octets\n",sizeof(char***));
    printf("La taille de float* est : %li octets\n",sizeof(float*));
    printf("La taille de float** est : %li octets\n",sizeof(float**));
    printf("La taille de float*** est : %li octets\n",sizeof(float***));
    printf("```\n");

    return 0;
}

/*

gcc -Wall -Wextra -o sizeof sizeof.c
./sizeof

*/