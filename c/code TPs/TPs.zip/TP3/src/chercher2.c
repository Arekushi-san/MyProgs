// Fichier: chercher2.c
// TP1 Exercice 3.8
// VENET ALEXIS et RODDE THEOPHILE
// le 30/09/2024

#include <stdio.h>
#include <stdlib.h>

int main() {

    //Declaration tableau de 10 phrase
    char tableau[10][50]={  {"Bonjour, comment ça va ?"},
                            {"Le temps est magnifique aujourd'hui."},
                            {"C'est une belle journée."},
                            {"La programmation en C est amusante."},
                            {"Les tableaux en C sont puissants."},
                            {"Les pointeurs en C peuvent être déroutants."},
                            {"Il fait beau dehors."},
                            {"La recherche dans un tableau est intéressante."},
                            {"Les structures de données sont importantes."},
                            {"Programmer en C, c'est génial."}
                            };

    char recherche[60];
    int trouve=0;
    int ligne;
    printf("\nrentrer la phrase a chercher :");
    fgets(recherche,sizeof(recherche),stdin);
    printf("\n");

    printf("On recherche : %s.\n", recherche);

    //boucle for permettant de parcourir la liste de phrase
    for(int i=0;i<10;i++){
        printf("\nphrase test :%s\n",tableau[i]);

        //boucle for parcourant les caracteres des deux phrases en meme temps
        for(int j=0;recherche[j]!='\0';j++){
            if(recherche[j]!=tableau[i][j]){
                break;
            }
            
            if(recherche[j+2]=='\0' && tableau[i][j+1]=='\0'){
                trouve=1;
                ligne=i;
                printf("ok");
            }
        }
        
    }

    if(trouve==1){
        printf("\nphrase trouve \n");
        printf("ligne %i :\n",ligne+1);
    }
    else{
        printf("\nnon trouve \n");
    }

    return 0;
}

/*

gcc -Wall -Wextra -o chercher2 chercher2.c
./chercher2

phrase test :
La recherche dans un tableau est intéressante.

*/
