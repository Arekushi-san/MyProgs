// Fichier: couleur_compteur.c
// TP1 Exercice 3.7
// VENET ALEXIS et RODDE THEOPHILE
// le 30/09/2024

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {

    //creation de la structure Couleurs
    struct Couleurs{
        int alpha;
        int rouge;
        int vert;
        int bleu;
    };

    //initialisation de srand
    srand(time(NULL));

    //variable ajout couleur, j et taille(compte taille de tableau)
    int ajout_coul=0;
    long unsigned int j;
    int taille=0;

    //creation d'une liste de n objets de la structure Couleurs
    struct Couleurs color[100];
    //couleur aleatoire, entre 0 et 255
    for(int i=0;i<100;i++){
        if((i%10)==0 && i!=0){
            color[i].alpha=1;
            color[i].rouge=1;
            color[i].vert=1;
            color[i].bleu=1;
        }
        else{
            color[i].alpha=rand() % (255);
            color[i].rouge=rand() % (255);
            color[i].vert=rand() % (255);
            color[i].bleu=rand() % (255);
        }
        
    }

    //Declaration tableau [ca,cr,cv,cb,compteur]
    int tableau[100][5]={{color[0].alpha,color[0].rouge,color[0].vert,color[0].bleu,1}};
    printf("Couleur %i \n",1);
    printf("%02x ",color[0].alpha);
    printf("0x%02x ",color[0].rouge);
    printf("0x%02x ",color[0].vert);
    printf("0x%02x ",color[0].bleu);
    taille=1;


    //boucle for permettant de parcourir la liste d'objet et d'afficher leurs valeurs
    for(int i=1;i<100;i++){
        ajout_coul=0;
        printf("Couleur %i \n",i+1);
        printf("%02x ",color[i].alpha);
        printf("0x%02x ",color[i].rouge);
        printf("0x%02x ",color[i].vert);
        printf("0x%02x ",color[i].bleu);
        
        printf("\n");

        //boucle for pour verifier si la couleur est deja présente dans le tableau
        for(j=0;*tableau[j]!='\0';j++){
            if(tableau[j][0]==color[i].alpha){
                if(tableau[j][1]==color[i].rouge){
                    if(tableau[j][2]==color[i].vert){
                        if(tableau[j][3]==color[i].bleu){
                            tableau[j][4]+=1;
                            ajout_coul=1;
                            break;
                        }
                    }
                }
            }
        }

        //ajout de la couleur dans le tableau si elle n'y etait pas deja presente
        if(ajout_coul==0){
            printf("-->ajout %ieme couleur dans tableau\n",taille+1);
            tableau[taille][0]=color[i].alpha;
            tableau[taille][1]=color[i].rouge;
            tableau[taille][2]=color[i].vert;
            tableau[taille][3]=color[i].bleu;
            tableau[taille][4]=1;
            taille+=1;
        }
        printf("\nok\n");
    }

    for(int k=0;*tableau[k]!='\0';k++){
        printf("\ntableau %i : %02x 0x%02x 0x%02x 0x%02x apparu %i fois\n",k+1,tableau[k][0],tableau[k][1],tableau[k][2],tableau[k][3],tableau[k][4]);
    }

    return 0;
}

/*

gcc -Wall -Wextra -o couleur_compteur couleur_compteur.c
./couleur_compteur

*/