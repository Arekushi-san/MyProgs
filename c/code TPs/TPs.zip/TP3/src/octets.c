// Fichier: octets.c
// TP1 Exercice 3.6
// VENET ALEXIS et RODDE THEOPHILE
// le 30/09/2024

#include <stdio.h>

void afficher_octets(void *ptr, size_t taille) {
    unsigned char tab[taille];
    unsigned char *octet = (unsigned char *)ptr;
    for (size_t i = 0; i < taille; i++) {
        tab[i]=octet[i];
        printf("%02x ", tab[i]);
    }
}


int main() {



    //declaration des variables
    short s = 258;
    int i = 3;
    long int li = 3;
    float f = 3.14;
    double d = 3.141592653589793;
    long double ld = 3.141592653589793238462643383279;

    //test short s = 258;
    


    printf("Je suis en configuration petit-boutiste\n");
    printf("\nOctets de short :\n");
    afficher_octets(&s, sizeof(s));

    printf("\nOctets de int :\n");
    afficher_octets(&i, sizeof(i));

    printf("\nOctets de long int :\n");
    afficher_octets(&li, sizeof(li));

    printf("\nOctets de float :\n");
    afficher_octets(&f, sizeof(f));

    printf("\nOctets de double :\n");
    afficher_octets(&d, sizeof(d));

    printf("\nOctets de long double :\n");
    afficher_octets(&ld, sizeof(ld));

    return 0;
}
/*

gcc -Wall -Wextra -o octets octets.c
./octets

*/