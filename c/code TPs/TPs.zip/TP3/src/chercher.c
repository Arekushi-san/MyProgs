// Fichier: chercher.c
// TP1 Exercice 3.4
// VENET ALEXIS et RODDE THEOPHILE
// le 29/09/2024

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    
    //initialisation de srand
    srand(time(NULL));

    //Declaration des variables
    int tableau[100];
    int i;
    int chercher;

    printf("Tableau :\n");
    //boucle for permettant de remplir tableau avec des nombres de -50 a 50
    for(i=0;i<100;i++){
        tableau[i]=(rand() % (101))-50;
        printf("%i ",tableau[i]);
        if(i%10==0 && i!=0){
            printf("\n");
        }
    }
    //pour lire plus facilement le tableau, retour a la ligne toutes les 10 valeurs pour l'affichage

    //saisi de la valeur a rechercher par l'utilisateur
    printf("\n\nEntrez l'entier que vous souhaitez chercher : ");
    scanf("%i", &chercher);

    //boucle for parcourant le tableau, arrêt de la boucle for si la valeur saisi correspond.
    for(i=0;i<100;i++){
        if(tableau[i]==chercher){
            printf("Resultat : entier present\n");
            break;
        }
        if(i==99){
            printf("Resultat : entier non present\n");
        }
    }

    return 0;
}

/*

gcc -Wall -Wextra -o chercher chercher.c
./chercher

*/