// Fichier: grand_petit.c
// TP1 Exercice 3.2
// VENET ALEXIS et RODDE THEOPHILE
// le 28/09/2024

#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main() {

    //initialisation de srand
    srand(time(NULL));

    //Declaration des variables
    int tableau[100];
    int max=0;
    int min=100;

    //boucle for permettant de remplir tableau avec des nombres de 1 a 100
    for(int i=0;i<100;i++){
        tableau[i]=rand() % (100)+1;
        printf("%i\n",tableau[i]);
    }

    //boucle for permettant d'obtenir le minimum/maximum du tableau
    for(int i=0;i<100;i++){
        if(max<tableau[i]){
            max=tableau[i];
        }
        else if(min>tableau[i]){
            min=tableau[i];
        }
    }

    //affichage
    printf("```\n");
    printf("Max : %i\nMin : %i\n",max,min);
    printf("```\n");

    return 0;
}

/*

gcc -Wall -Wextra -o grand_petit grand_petit.c
./grand_petit

*/