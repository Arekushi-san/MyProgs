On a realise l'ensemble des exercices du TP3

bibliotheque utilise :
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

Groupe A

Reference :
(Pour l'exercice grand_petit.c)
forum : https://stackoverflow.com/questions/822323/how-to-generate-a-random-int-in-c
(Pour recherche_dichotomique.c)
aide du site wikipedia : https://fr.wikipedia.org/wiki/Recherche_dichotomique


niveau de difficulté : intermediaire

Commentaires :
    
    grand_petit.c :
    importation de stdlib.h et de time.h permet d'avoir une valeur aleatoire
    differente a chaque fois.
    le rand() ne suffit pas a lui seul, renvoie des valeurs très similaires
    a chaque repetition de code.

    recherche_dichotomique.c :
    On a applique la recherche dichotomique avec l'explication de wikipedia,
    pour rechercher un nombre en particulier dans une liste de nombre triee.

    octets.c :
    %02x permet de mettre un 0 avant le nombre si un seul chiffre.
    Le premier octet correspond au dernier octet de la valeur, car machine
    utilisee en petit boutiste.
    On pourrait realiser un affichage adapte avec une fonction en realisant
    un test pour voir si petit/grand boutiste, et ensuite afficher le bon
    sens de lecture des octets.
    
    couleur_compteur.c :
    L'objectif de cet exercice etant de verifier a chaque fois dans le tableau si la couleur a deja ete creee,
    nous avons realiser des couleurs aleatoires sauf pour les couleurs avec un indice multiple de 10.
    De ce fait, la couleur avec 1 1 1 1 apparait dans la plupart des cas 9 fois.
    Les autres couleurs apparaissent generalement qu'une seul fois, la probabilite d'avoir 2 fois la
    meme couleur etant de 1/(256 x 256 x 256 x 256).

    chercher2.c :
    fgets ajoute en plus le caractere de retour a la ligne '\n'.
    On verifie donc que le caractere +2 correspond a la fin de chaine.
    On pourrait aussi verifier que le caractere +1 est le retour a la ligne (verification
    de la fin de chaine avant de demarrer la prochaine iteration).
    
    Amelioration/Autre fonctionnalite : Si on veut verifier si un mot/suite de lettre est present dans
    l'ensemble des phrases, on peut remplacer l.40 le "break" par 'continue' afin de
    parcourir chaque lettre de chaque phrase, puis enlever la condition "tableau[i][j+1]=='\0'"
    (l.44).
