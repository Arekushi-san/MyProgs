On a realise l'ensemble des exercices du TP4

# Bibliothèques
* #include <stdio.h>
* #include <stdlib.h>
* #include <time.h>

# Références
* https://koor.fr/C/cstdio/fopen.wp (pour utilisation de fopen)


# Difficulté
* intermediaire

# Commentaires
* etudiant_bd.c :
    Dans ce code, j'ai reutilise le code de l'exercicee 4.2 pour ouvrir des fichiers .txt et les modifier,
    et le code d'etudiant2.c pour la structure de l'etudiant.
    De plus, j'ai utilise fopen dans un premier temps pour supprimer le texte dans le fichier txt, puis
    dans un second temps ajouter un a un les differents message a ajouter.

* main.c
    Case=1, Exo 4.1:
    Cette exercice a pour but de faire notre premiere gestion des fichiers
    .h qui relie le fichier .c contenant les fonctions, avec le fichier .c
    fonction principale.

    Case=2, Exo 4.2:
    On a pu dans cet exercice editer un fichier .txt a partir du programme, notions d'ouverture et fermeture
    du fichier et ecriture dans le fichier.
    Il etait plus simple pour nous d'utiliser le fget pour recuperer la chaine de caractere saisi par
    l'utilisateur, mais nous pouvons realiser la meme operation avec la commande scanf(" %[^\n]",msg);
    qui permet de recuperer tout les caracteres saisi par l'utilisateur jusqu'au retour a la ligne.

    Case=3, Exo 4.7:
    On a cree des couleurs sous forme de tableau, couleurs a enregistrer dans un tableau de liste.c.

* etudiant_bd.c :
    En reutilisant la methode utilise dans l'exercice suivant, on a pu editer le fichier texte afin de
    rentrer les donnees des 5 etudiants, donnees stocke en tant qu'objet de la classe Etudiant.
    La difficulte a ete de les stocker comme demander dans l'enonce.
    Il fallait aussi penser a supprimer le texte dans le fichier.txt avant de rentrer les donnees.
    Avec l'aide de la bibliotheque string.h, il etait plus facile de concatener les chaines de caractere,
    cela a aussi permis de realiser moins de calcul.
    Aussi, l'appel de la fonction ecrire_dans_fichier n'est realiser qu'une seul fois par etudiant.

* factorielle.c :
    Cet exercice est present pour nous montrer la fonction de recursivite, surtout le fait que la
    fonction s'appelle elle-même dans son code.
* chercherfichier.c :
    chercher une phrase dans un fichier choisi. On a enregistré l'occurance a l'indice du tableau Presence_Phrase
    si la 5eme ligne, Presence_Phrase[4]+=1.

* liste.c :
    On a cree la fonction parcours, insertion et init_liste, voici les explications :
        init_liste : permet de cree une liste qui est null.
        insertion : permet d'inserer les couleurs une par une sur le "devant" de la liste (comme une pile).
        parcours : parcour la liste de couleur, en utilisant l'addresse de la couleur suivante pour parcourir
        les couleurs une par une.
* liste.h :
    creation des differentes structures :
        couleur : structure avec r, g, b et a.
        noeud : permet d'associer une couleur avec l'addresse de la prochaine couleur (de la liste).
        liste_couleurs : permet d'avoir une liste associé avec une couleur en premier.
        Grace a cela, on peut avec la fonction insertion cree rapidement une liste sous format de pile (ou LIFO),
        en associant l'addresse de la couleur precedentes sur la nouvelle couleur et l'addresse a la tete de la liste
        celle de la nouvelle couleur.

