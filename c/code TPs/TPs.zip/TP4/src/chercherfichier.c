// Fichier: chercherfichier.c
// TP4 Exercice 4.6
// VENET ALEXIS et RODDE THEOPHILE
// le 10/10/2024

#include <stdio.h>
#include <string.h>

int lire_fichier(char *nom_de_fichier,char *phrase,int *Presence_Phrase){
    //traite tt les fichiers de taille inferieur a 10 Ko par ligne et et 10k lignes
    FILE *fichier = fopen(nom_de_fichier, "r");

    if (fichier == NULL) {
        printf("Erreur lors de l'ouverture du fichier\n");
        return -1;
    }

    //Declaration des variables
    char ligne[10000]="";
    char *pos;
    int Pres_compte=0; //compteur occurences dans la ligne
    int line_compte=0; //compteur de ligne

    //on récupère chaque ligne du fichier
    while ((fgets(ligne,sizeof(ligne),fichier)) != NULL) {
        
        pos=ligne;
        Pres_compte=0;

        //on test la phrase sur toute la ligne
        while ((pos = strstr(pos, phrase)) != NULL) {
            Pres_compte+=1;
            pos += strlen(phrase);
        }

        Presence_Phrase[line_compte]=Pres_compte;
        line_compte+=1;
    }

    fclose(fichier);
    return line_compte;
}


int main(int argc,char *argv[]) {

    if(argc<2){
        printf("Non saisi de l'utilisateur. Fermeture du programme.\n");
        return 0;
    }

    //Declaration des variables
    int Presence_Phrase[10000]; //tableau avec occurence de la phrase ds chaque ligne
    char Phrase[10000];
    printf("\nEntrez la phrase que vous souhaitez rechercher : ");
    scanf(" %[^\n]",Phrase);

    //lecture du .txt saisi par l'utilisateur
    int max_ligne=lire_fichier(argv[1],Phrase,Presence_Phrase);

    if(max_ligne==-1){
        printf("erreur fichier\n");
        return 0;
    }

    //Affichage
    printf("fichier ouvert : %s \n",argv[1]);
    printf("Nombre de ligne : %i \n",max_ligne);

    int Switch=0; //permet de verifier si il y a eu au moins une occurence dans le fichier

    //boucle for permettant d'afficher toutes les lignes avec occurences.
    for (int i=0;i<max_ligne;i++){
        //verifie si il y a eu au moins une occurence dans la ligne
        if (Presence_Phrase[i]>0){
            printf("Ligne %i, %i fois\n",i+1,Presence_Phrase[i]);
            Switch=1;
        }
    }

    //Affichage si aucune occurence dans le fichier
    if (Switch==0){
        printf("aucune occurence de la phrase dans le fichier %s\n",argv[1]);
    }


    return 0;
}


/*
gcc -Wall -Wextra -o chercherfichier chercherfichier.c
./chercherfichier
*/