// Fichier: Calcule.c
// TP4 Exercice 4.4
// VENET ALEXIS et RODDE THEOPHILE
// le 10/10/2024

#include <stdio.h>
#include <stdlib.h>
#include "operator.h"
#include <string.h>

int main(int argc,char *argv[]) {

    //verification du nombre d'entree dans la commande ./main
    if (argc < 4) {
        printf("erreur");
        return 0;
    }

    //Declaration des variables
    char op=argv[1][0];
    int num1=atoi(argv[2]);
    int num2=atoi(argv[3]);
    
    //affichage des variables recuperees
    printf("num1 : %i num2 : %i op : %c\n",num1,num2,op);

    //switch qui permet de selectionner le calcul a realiser en fonction de op
    switch(op){
        
        case '+':
            printf("Resultat : %i\n",add(num1,num2));
            break;

        case '-':
            printf("Resultat : %i\n",sub(num1,num2));
            break;

        case '*':
            printf("Resultat : %i\n",mult(num1,num2));
            break;

        case '/':
            if (op == '/' && num2 == 0) {   //Si division par zéro
                printf("Erreur (Division par zéro)\n");
                break;
            }
            
            printf("Resultat : %.3f\n",division(num1,num2));
            break;

        case '%':
            printf("Resultat : %i\n",modul(num1,num2));
            break;

        case '&':
            printf("Resultat : %i\n",et(num1,num2));
            break;

        case '|':
            printf("Resultat : %i\n",ou(num1,num2));
            break;

        case '~':
            int resultat[2]={num1,num2};
            til(num1,num2,resultat);
            printf("Resultat : \n~num1 = %i\n~num2 = %i\n",resultat[0],resultat[1]);
            break;
            
        default:
            printf("erreur saisi\n");

    }

    return 0;
}


/*
gcc -Wall -Wextra -o calcule calcule.c operator.c

./calcule + 15 8

attention : pour les symboles *, | et ~, il faut mettre des guillemets lors de la commande
exemple : ./calcule '*' 15 8

*/
