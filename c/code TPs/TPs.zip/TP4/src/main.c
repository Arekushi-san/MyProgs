// Fichier: main.c
// TP4 Exercice 4.1 - main
// TP4 Exercice 4.2 - main
// TP4 Exercice 4.7 - main
// VENET ALEXIS et RODDE THEOPHILE
// le 08/10/2024

#include <stdio.h>
#include "operator.h"
#include "fichier.h"
#include "liste.h"

int main() {
    
    //int Case=1; //Exercice 4.1
    //int Case=2; //Exercice 4.2
    int Case=3; //Exercice 4.7
    
    //switch qui permet de selectionner le calcul a realiser en fonction de op
    switch(Case){
        case 1:
            //Declaration des variables
            int num1;
            int num2;
            char op;

            //saisi par l'utilisatuer des 2 valeurs et de l'operateur
            printf("Entrez num1 : ");
            scanf("%i", &num1);
            printf("Entrez num2 : ");
            scanf("%i", &num2);
            printf("Entrez l'opérateur (+, -, *, /, (modulo),&, |, ~) : ");
            scanf(" %c", &op);

            //switch qui permet de selectionner le calcul a realiser en fonction de op
            switch(op){
                
                case '+':
                    printf("Resultat : %i\n",add(num1,num2));
                    break;

                case '-':
                    printf("Resultat : %i\n",sub(num1,num2));
                    break;

                case '*':
                    printf("Resultat : %i\n",mult(num1,num2));
                    break;

                case '/':
                    printf("Resultat : %.3f\n",division(num1,num2));
                    break;

                case '%':
                    printf("Resultat : %i\n",modul(num1,num2));
                    break;

                case '&':
                    printf("Resultat : %i\n",et(num1,num2));
                    break;

                case '|':
                    printf("Resultat : %i\n",ou(num1,num2));
                    break;

                case '~':
                    int resultat[2]={num1,num2};
                    til(num1,num2,resultat);
                    printf("Resultat : \n~num1 = %i\n~num2 = %i\n",resultat[0],resultat[1]);
                    break;
                    
                default:
                    printf("erreur saisi\n");

            }
            break;

        case 2:

            //saisie par l'utilisateur de l'action voulu
            printf("Que souhaitez-vous faire?\n1.Lire un fichier\n2.Ecrire dans un fichier\nVotre choix : ");
            int a;
            char txt[60];
            scanf("%d",&a);

            //saisie par l'utilisateur du nom du fichier a manipuler
            printf("\nQuel est le nom du fichier à utiliser : ");
            scanf(" %s",txt);
            
            
            //lecture du fichier
            if(a == 1){
                lire_fichier(txt);
            }

            //Ecriture dans le fichier
            if(a == 2){
                char msg[60];
                printf("%s","Quel message voulez-vous écrire dans ce fichier : ");
                scanf(" %[^\n]",msg);
                ecrire_dans_fichier(txt,msg);
                printf("le message a ete ecrit dans le fichier %s.",txt);
            }

            printf("\n");
            
            break;

        
        case 3:
            struct liste_couleurs ma_liste;
            init_liste(&ma_liste);

            // Créer et insérer 10 couleurs dans la liste
            struct couleur couleurs[10] = {
                {0xFF, 0x00, 0x00, 0xFF}, // Rouge
                {0x00, 0xFF, 0x00, 0xFF}, // Vert
                {0x00, 0x00, 0xFF, 0xFF}, // Bleu
                {0xFF, 0xFF, 0x00, 0xFF}, // Jaune
                {0x00, 0xFF, 0xFF, 0xFF}, // Cyan
                {0xFF, 0x00, 0xFF, 0xFF}, // Magenta
                {0x80, 0x80, 0x80, 0xFF}, // Gris
                {0x00, 0x00, 0x00, 0xFF}, // Noir
                {0xFF, 0xFF, 0xFF, 0xFF}, // Blanc
                {0x7F, 0x00, 0x7F, 0xFF}  // Violet
            };

            // Ajouter les couleurs à la liste
            for (int i = 0; i < 10; i++) {
                insertion(&couleurs[i], &ma_liste);
            }

            // Afficher toutes les couleurs de la liste
            printf("Liste des couleurs :\n");
            parcours(&ma_liste);

        
            break;
    
    
    }

    return 0;
}


/*

gcc -Wall -Wextra -o main main.c liste.c fichier.c operator.c

./main

*/