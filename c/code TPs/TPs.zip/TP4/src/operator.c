// Fichier: operator.c
// TP4 Exercice 4.1 - fonctions
// VENET ALEXIS et RODDE THEOPHILE
// le 07/10/2024


#include <stdio.h>

//Fonctions pour les differents operateurs

//Addition
int add(int a, int b) {
    return a + b;
}

//Soustraction
int sub(int a, int b){
    return a-b;
}

//Multiplication
int mult(int a, int b){
    return a*b;
}

//Division
float division(int a, int b){
    return (float)a/b;
}

//Modulo
int modul(int a, int b){
    return a%b;
}

//Fonction ET
int et(int a, int b){
    return a&b;
}

//Fonction OU
int ou(int a, int b){
    return a|b;
}

//Fonction TIL
//demande un tableau en entree Calc pour renvoyer la valeur directement a l'addresse du tableau
void til(int a, int b,int Calc[2]){
    Calc[0]= ~a;
    Calc[1]= ~b;
}


