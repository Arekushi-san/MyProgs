// Fichier: fichier.c
// TP4 Exercice 4.2 - fonctions
// VENET ALEXIS et RODDE THEOPHILE
// le 07/10/2024

#include <stdio.h>

char lire_fichier(char * nom_de_fichier){
    //ouverture du fichier
    FILE *fichier = fopen(nom_de_fichier, "r");

    //Verification de la presence du fichier
    if (fichier == NULL) {
        printf("Erreur lors de l'ouverture du fichier\n");
        return 1;
    }

    char c;
    printf("Contenue du fichier %s :\n",nom_de_fichier);

    //affichage de tout les caracteres du fichier avec une boucle while
    while ((c = fgetc(fichier)) != EOF) {
        printf("%c", c);
    }

    //fermeture du fichier
    fclose(fichier);

    return 0;
}

char ecrire_dans_fichier(char * nom_de_fichier, char * message){
    //ouverture du fichier
    FILE *fichier = fopen(nom_de_fichier, "w");
    if (fichier == NULL) {
        printf("Erreur lors de l'ouverture du fichier\n");
        return 1;
    }
    //ecriture dans le fichier avec fprintf
    fprintf(fichier, "%s", message);

    //fermeture du fichier
    fclose(fichier);

    return 0;
}


