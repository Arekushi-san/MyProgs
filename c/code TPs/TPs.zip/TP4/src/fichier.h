// Fichier: main.c
// TP4 Exercice 4.2 - preprocesseur
// VENET ALEXIS et RODDE THEOPHILE
// le 13/10/2024

#ifndef __FICHIER_H__
#define __FICHIER_H__

char lire_fichier(char * nom_de_fichier);
char ecrire_dans_fichier(char * nom_de_fichier, char * message);

#endif //__FICHIER_H__