// Fichier: etudiant_bd.c
// TP4 Exercice 4.3
// VENET ALEXIS et RODDE THEOPHILE
// le 07/10/2024

#include <stdio.h>
#include <string.h>

int ecrire_dans_fichier(char * message,int init){
    
    if(init==0){
        //remise du fichier .txt a vide pour la première donnee
        //ouverture du fichier en mode ecriture et fermeture du fichier
        FILE *fichier = fopen("etudiant.txt", "w");
        fclose(fichier);
        init+=1;
    }

    //ouverture du fichier en mode ajout
    FILE *fichier = fopen("etudiant.txt", "a");
    
    //verification de la presence du fichier
    if (fichier == NULL) {
        printf("Erreur lors de l'ouverture du fichier\n");
        return 0;
    }

    //Ajout dans le fichier du message et fermeture du fichier
    fprintf(fichier, "%s", message);
    fclose(fichier);

    return 1;
}

int main() {

    //creation de la structure Etudiant
    struct Etudiant{
        char nom[60];
        char prenom[60];
        char addresse[60];
        char note_1[30];
        char note_2[30];
    };

    //Creation des variables
    struct Etudiant etudiants[5];
    int i;
    char nom[60]; //Nom de l'etudiant
    char prenom[60]; //Preom de l'etudiant

    char addresse[60]; //Addresse de l'etudiant
    char note_1[30]; //Note 1 de l'etudiant
    char note_2[30]; //Note 2 de l'etudiant
    char msg[200]; //chaine de caractere correspondant a la ligne a ecrire dans le fichier contenant toutes les informations de l'etudiant
    char Num_Etudiant[60]; //Nom de l'etudiant

    int init=0;

    
    



    //boucle for permettant la saisi et l'enregistrement des donnees des 5 etudiants
    for(i=0;i<5;i++){
        printf("\nEntrez les details de l'etudiant.e %i : ",i+1);

        // %[^\n] : prendre tout les caracteres sauf le \n
        //enregistrement des donnees de chaque etudiant en tant qu'objet de classe etudiant
        //dans la liste etudiants

        printf("\nNom : ");
        scanf(" %[^\n]",nom);
        strcpy(etudiants[i].nom,nom);

        printf("\nPrenom : ");
        scanf(" %[^\n]",prenom);
        strcpy(etudiants[i].prenom,prenom);

        printf("\nAdresse : ");
        scanf(" %[^\n]",addresse);
        strcpy(etudiants[i].addresse,addresse);

        printf("\nNote 1 : ");
        scanf(" %[^\n]",note_1);
        strcpy(etudiants[i].note_1,note_1);

        printf("\nNote 2 : ");
        scanf(" %[^\n]",note_2);
        strcpy(etudiants[i].note_2,note_2);
   }


    //boucle for permettant l'affichage des donnees des 5 etudiants
    printf("\n");
    for(int i=0;i<5;i++){
        //Ajout dans msg de chaque information, avec des separateur pour differencier les differentes information
        //affichage : Étudiant.e i : Nom / Prenom / Addresse / Note1 / Note2

        //Etudiant.e i dans msg
        strcpy(msg,"Étudiant.e ");
        sprintf(Num_Etudiant,"%d",i+1);
        strcat(msg,Num_Etudiant);
        strcat(msg," : ");

        //nom de l'etudiant dans msg
        strcat(msg,etudiants[i].nom);
        strcat(msg," / ");

        //prenom de l'etudiant dans msg
        strcat(msg,etudiants[i].prenom);
        strcat(msg," / ");

        //addresse de l'etudiant dans msg
        strcat(msg,etudiants[i].addresse);
        strcat(msg," / ");

        //note_1 de l'etudiant dans msg
        strcat(msg,etudiants[i].note_1);
        strcat(msg," / ");

        //note_2 de l'etudiant dans msg et ecriture dans le fichier
        strcat(msg,etudiants[i].note_2);
        strcat(msg,"\n");
        ecrire_dans_fichier(msg,init);

        init=1;

    }
    
return 0;
}

/*

gcc -Wall -Wextra -o etudiant_bd etudiant_bd.c
./etudiant_bd

Marchal
Dupont
29, rue victoire, Lyon
11.0
13.0
Stico
Lama
12, rue victoire, Lyon
11.0
13.0
Nenpeplu
Jean
12, rue largo, Lyon
15.0
7.0
Golade
Thierry
14, rue miel, Lyon
14.0
11.0
Golade
Henry
1, rue miel, Lyon
1.0
1.0

Pour plus de facilite, lors de la proposition de la saisi, veuillez selectionner
corectement les informations ci-dessus et les coller dans l'espace de saisi, puis
appuyer sur entrer.
J'ai remarqué qu'en collant directement les 27 lignes pour les informations l'affichage de l'invite de commande est
dépassé par l'affichage, mais on se rend compte que les instructions passés à la console fonctionne bien.

*/