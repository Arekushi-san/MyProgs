// Fichier: operator.c
// TP4 Exercice 4.7 - fonctions
// VENET ALEXIS et RODDE THEOPHILE
// le 13/10/2024

#include "liste.h"

// Fonction pour initialiser la liste
void init_liste(struct liste_couleurs* liste) {
    liste->tete = NULL;
}

// Fonction pour insérer une couleur dans la liste
void insertion(struct couleur* couleur, struct liste_couleurs* liste) {

    //utilisation de malloc afin de faire une taille dynamique
    //ajout de (struct noeud*) afin de preciser la nature de l'objet a dimensionner
    struct noeud* nouveau_noeud = (struct noeud*)malloc(sizeof(struct noeud));
    
    if (nouveau_noeud == NULL) {
        fprintf(stderr, "Erreur d'allocation mémoire\n");
        return;
    }

    //Addresse de la couleur suivante
    nouveau_noeud->couleur = *couleur;
    nouveau_noeud->suivant = liste->tete;
    liste->tete = nouveau_noeud;
}

// Fonction pour parcourir et afficher toutes les couleurs de la liste
void parcours(struct liste_couleurs* liste) {

    //addresse prise du debut de la liste
    struct noeud* actuel = liste->tete;

    //affichage de toutes les couleurs
    while (actuel != NULL) {
        printf("Couleur - R: %02X, G: %02X, B: %02X, A: %02X\n",
               actuel->couleur.r, actuel->couleur.g, actuel->couleur.b, actuel->couleur.a);
        actuel = actuel->suivant;
    }
}
