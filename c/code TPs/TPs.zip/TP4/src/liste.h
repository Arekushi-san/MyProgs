// Fichier: liste.h
// TP4 Exercice 4.7 - preprocesseur
// VENET ALEXIS et RODDE THEOPHILE
// le 13/10/2024

#ifndef LISTE_H
#define LISTE_H

#include <stdio.h>
#include <stdlib.h>

//Structure pour les couleurs, avec alpha (transparence de la couleur)
struct couleur {
    char r;
    char g;
    char b;
    char a;
};

//Structure avec la couleur et la position de la couleur suivante
struct noeud {
    struct couleur couleur;
    struct noeud* suivant;
};

//Structure permettant d'avoir l'addresse de la premiere couleur
struct liste_couleurs {
    struct noeud* tete;
};

void init_liste(struct liste_couleurs* liste);
void insertion(struct couleur* couleur, struct liste_couleurs* liste);
void parcours(struct liste_couleurs* liste);

#endif
