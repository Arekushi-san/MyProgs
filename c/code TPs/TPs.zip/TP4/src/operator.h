// Fichier: operator.h
// TP4 Exercice 4.1 - preprocesseur
// VENET ALEXIS et RODDE THEOPHILE
// le 08/10/2024
// operator.h

#ifndef OPERATOR_H
#define OPERATOR_H


int add(int a, int b);
int sub(int a, int b);
int mult(int a, int b);
float division(int a, int b);
int modul(int a, int b);
int et(int a, int b);
int ou(int a, int b);
void til(int a, int b,int Calc[2]);



#endif
