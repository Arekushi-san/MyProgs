On a realise l'exercice 6.1 et 6.2

# Bibliothèques
* #include <stdio.h>
* #include <stdlib.h>
* #include <time.h>
* #include <sys/types.h>
* #include <sys/stat.h>
* #include <sys/socket.h>
* #include <fcntl.h>
* #include <unistd.h>
* #include <string.h>
* #include <netinet/in.h>
* #include <search.h>
* #include <math.h>
* #include <signal.h>




# Références
* Pour la recherche sur le cJson non fini :
https://hayageek.com/cjson-examples-parse-write-print-json-with-cjson-in-c/


# Difficulté
* très difficile

# Commentaires
* Exercice 6.1 :
        Nous avons eu beaucoup de difficulté à faire fonctionner le code de base, à cause de notre ordinateur ou
        a cause de la difficulté du code, qui aborde des librairies qui nous sont inconnus.
* Exercice 6.2 :
        Après avoir réussi à faire fonctionner notre code, nous avons pu assez facilement rajouter la variable de
        couleur avec un scanf afin de le mettre dans la boucle comme condition limite. Mais nous avons eu beaucoup de
        probleme car nous avons, au debut, mal modifier le code, ce qui nous a entrainer beaucoup d'erreur. Mais avec l'aide
        de nos camarade et de l'intervenant, nous avons pu debloquer notre code.

* Element de resolution pour l'exercice 6.3 : avec la bibliotheque cJson, nous aurions du creer un premier fichier cJson
avec les elements a partager avec le serveur, puis recuperer ces informations avec le serveur, puis le serveur aurait du 
creer un cjson de reponse avec les informations necessaire et le client aurait pu lire ces informations. Avec la bibliotheque,
nous avons eu beaucoup trop d'erreur, et donc n'avons pas pu reussir l'exercice, je pense qu'on a modifier en meme temps le code
deja present, ce qui a entrainer une suite d'erreurs.



