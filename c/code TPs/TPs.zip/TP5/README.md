On a realise l'ensemble des exercices du TP5

# Bibliothèques
* #include <stdio.h>
* #include <stdlib.h>
* #include <time.h>

# Références
* Pour bibliotheque de readdir/comprehension de la fonction :
http://manpagesfr.free.fr/man/man3/readdir.3.html


# Difficulté
* difficile

# Commentaires
* repertoire.c
        repertoire.c (Exercice 5.1) :
        Le plus dure a ete de comprendre comment fonctionner la fonction readdir et opendir et
        comment manipuler l'ouverture de fichier.
        Aussi, ayant une machine virtuelle Ubuntu, nous avons du ajouter /mnt/ pour se mettre
        dans le repertoire courant des disques.
        Puis, l'utilisateur peut effectuer la commande ./repertoire.c d/

        repertoire.c (Exercice 5.2) :
        Objectif : ouvrir les dossiers/sous dossier ds repertoir courant
        Après avoir realisé notre boucle while permettant de verifier tout les fichiers dans
        le dossier cible et regardé si leur types etait de type DT_DIR, nous avions un code qui marche,
        mais affichant un probleme de segmentation.
        Il fallait que nous verifions si ent = readdir(dirp)==NULL car, lors de la manipulation des variables,
        lors du parcour du premier dossier, `nous remplacions la valeur de dir, donc probleme d'espace`

        repertoire.c (Exercice 5.3) :
        Pour cette exercice, il nous fallait sauvegarder le chemin afin de pouvoir parcourir correctement
        les differents repertoire, et aussi un compteur.
        Avec cela, il ne fallait pas liberer path, seulement a la toute fin, afin de garder le chemin.

* Exercice 5.5 :
        serveur : s'il y a au debut du message "calcule :", alors la fonction correspondant au calcul est appelé.
        ensuite, les différentes fonctions pour le calcule sont présentes, renvoyant une chaine de caractere au client
        correspondant a la solution du calcul.
        client : Il faut chez le client envoyer un message a la bonne section du serveur.
        -->envoyer le calcule avec le client avec la formule : calcule : op num1 num2, op corrrespondant a un des
        operateurs pris en charge par le serveur, et num1 num2 deux entiers.
* Exercice 5.6 :
        serveur : calcule les additions simples envoyées par le client.
        client : traite les données des etudiants, les enregistres, puis additionne le tout afin d'avoir la moyenne general
        de tout les etudiants et de toutes les notes.
        -->envoyer la demande du calcul de la moyenne avec la formule : moyenne

Amelioration possible :
    Puisque nous avons recuperer toutes les valeurs, nous aurions pu rajouter les options moyenne notei, qui permet de 
    faire la moyenne de tout les etudiants par rapport a une de leur note, ou realiser moyenne etudianti, qui permet de
    faire la moyenne de toutes les notes d'un etudiant.



