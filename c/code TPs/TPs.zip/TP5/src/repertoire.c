// Fichier: repertoire.c
// TP4 Exercice 5.1 5.2 et 5.3 - fonctions et main
// VENET ALEXIS et RODDE THEOPHILE
// le 14/10/2024


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

int lire_dossier(char nom_repertoire[1000]) {

    DIR *dirp = opendir(nom_repertoire);
    if (dirp == NULL) {
        perror("opendir");
        return(EXIT_FAILURE);
    }

    struct dirent * ent;
    while(1) {
        ent = readdir(dirp);
        if (ent == NULL) {
            break;
        }
        printf("%s\n", ent->d_name);
    }
    closedir(dirp);
    return(0);
}

int lire_dossier_recursif(char *nom_repertoire){

    printf("valeur repertoire %s",nom_repertoire);
    DIR *dirp = opendir(nom_repertoire);
    if (dirp == NULL) {
        perror("opendir");
        return(EXIT_FAILURE);
    }

    struct dirent * ent;
    while(1) {
        ent = readdir(dirp);
        if(ent==NULL){
            perror("opendir");
            closedir(dirp);
            return(EXIT_FAILURE);
        }
    

        printf("%s\n", ent->d_name);

        if (ent->d_type==DT_DIR){
            if (strcmp(ent->d_name,".") && strcmp(ent->d_name,"..")){
				char *path = malloc(strlen(ent->d_name)+strlen(nom_repertoire)+2);
                if (path == NULL) {
                    perror("opendir");
                    closedir(dirp);
                    return(EXIT_FAILURE);
                }
				strcpy(path, nom_repertoire);
				strcat(path,"/");
				strcat(path,ent->d_name);
				lire_dossier_recursif(path);
				free(path);
			}
        }
    }

}

int lire_dossier_iteratif(char *nom_repertoire){

    //Declaration variable
    char *Tab_Repertoire[1000];
    Tab_Repertoire[0]=nom_repertoire;
    int j=1;
    struct dirent * ent;
    DIR *dirp;
    char *path;


    for(int i=0;i<j;i++){
        printf("valeur repertoire %s",nom_repertoire);
        dirp = opendir(Tab_Repertoire[i]);

        while(1) {

            ent = readdir(dirp);
            if(ent==NULL){
                perror("opendir");
                closedir(dirp);
                break;
            }

            printf("%s\n", ent->d_name);

            if (ent->d_type==DT_DIR){
                if (strcmp(ent->d_name,".") && strcmp(ent->d_name,"..")){
                    path = malloc(strlen(ent->d_name)+strlen(Tab_Repertoire[i])+2);
                    if (path == NULL) {
                        perror("opendir");
                        closedir(dirp);
                        break;
                    }
                    printf("lmao %s\n",path);
                    strcpy(path, Tab_Repertoire[i]);
                    strcat(path,"/");
                    strcat(path,ent->d_name);
                    printf("%s\n",path);
                    
                    if (j < 1000){
                        Tab_Repertoire[j] = path;
                        j+=1;
                        break;
				    }
                    
                }
                
                
            }
            
        }
        
    }
    free(path);
    return 0;
}




int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Utilisation : %s <nom_du_repertoire>\n", argv[0]);
        return 1;
    }

    char nom_repertoire[1000] = "/mnt/";
    strcat(nom_repertoire,argv[1]);

    //int Case=1; //Exercice 5.1
    //int Case=2; //Exercice 5.2
    int Case=3; //Exercice 5.3

    switch (Case){
    case 1:
        lire_dossier(nom_repertoire);
        break;
    
    case 2:
        lire_dossier_recursif(nom_repertoire);
        break;

    case 3:
        lire_dossier_iteratif(nom_repertoire);
        break;
    }

    return 0;
}



/*
gcc -Wall -Wextra -o repertoire repertoire.c
./repertoire d/Docu-Alexis/4ETI/CRP

ajout artificielle de /mnt/ qui positionne le repertoire de base a la selection des disques du PC
d/DossierA/DossierB/.../dossierN
c/ ou d/

*/

//http://manpagesfr.free.fr/man/man3/readdir.3.html