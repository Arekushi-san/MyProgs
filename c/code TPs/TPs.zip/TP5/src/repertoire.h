// Fichier: repertoire.h
// TP4 Exercice 5.6 - preprocesseur
// VENET ALEXIS et RODDE THEOPHILE
// le 04/11/2024

#ifndef __REPERTOIRE_H__
#define __REPERTOIRE_H_

int lire_dossier(char nom_repertoire[1000]);



#endif //__REPERTOIRE_H__