// Fichier: client.c
// TP5 Exercice 5.4, 5.5 et 5.6
// VENET ALEXIS et RODDE THEOPHILE
// le 31/10/2024

/*
 * SPDX-FileCopyrightText: 2021 John Samuel
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include "client.h"

/**
 * Fonction pour envoyer et recevoir un message depuis un client connecté à la socket.
 *
 * @param socketfd Le descripteur de la socket utilisée pour la communication.
 * @return 0 en cas de succès, -1 en cas d'erreur.
 */
int envoie_recois_message(int socketfd,char *message){
    char data[1024];

    // Réinitialisation de l'ensemble des données
    memset(data, 0, sizeof(data));

    // Construit le message avec une étiquette "message: "
    strcpy(data, "message: ");
    strcat(data, message);

    // Envoie le message au serveur
    int write_status = write(socketfd, data, strlen(data));
    if (write_status < 0){
    
        perror("Erreur d'écriture");
        return -1;
    }

    // Réinitialisation de l'ensemble des données
    memset(data, 0, sizeof(data));

    // Lit les données de la socket
    int read_status = read(socketfd, data, sizeof(data));
    if (read_status < 0){
    
        perror("Erreur de lecture");
        return -1;
    }

    // Affiche le message reçu du serveur
    printf("Message reçu: %s\n", data);

    return 0; // Succès
}

char lire_fichier(char * nom_de_fichier){
    //ouverture du fichier
    printf("\nle fichier : %s\n",nom_de_fichier);
    FILE *fichier = fopen(nom_de_fichier, "r");

    //Verification de la presence du fichier
    if (fichier == NULL) {
        printf("Erreur lors de l'ouverture du fichier\n");
        return 1;
    }

    char c;
    char note[10]="";
    int i=0;
    printf("Contenu du fichier %s : ",nom_de_fichier);

    //affichage de tout les caracteres du fichier avec une boucle while
    while ((c = fgetc(fichier)) != EOF) {
        note[i]=c;
        i+=1;
    }
    
    //on considere que les infos de l'etudiant sont des entiers
    int noteI=atoi(note);

    //fermeture du fichier
    fclose(fichier);

    return noteI;
}

int envoie_operateur_numeros(int socketfd,char*message){

    char data[1024];

    // Réinitialisation de l'ensemble des données
    memset(data, 0, sizeof(data));

    // Construit le message avec l'étiquette "calcule : " déja présente

    strcpy(data, message);

    // Envoie le message au serveur
    int write_status = write(socketfd, data, strlen(data));
    if (write_status < 0){
        perror("Erreur d'écriture");
        return -1;
    }

    // Réinitialisation de l'ensemble des données
    memset(data, 0, sizeof(data));

    // Lit les données de la socket
    int read_status = read(socketfd, data, sizeof(data));
    if (read_status < 0){
        perror("Erreur de lecture");
        return -1;
    }

    // Affiche le message reçu du serveur
    printf("%s\n", data);

    return 0; // Succès
}

int envoie_operateur_etudiant(int socketfd,char *){

    char data[1024];
    memset(data, 0, sizeof(data));
    // Réinitialisation de l'ensemble des données
    

    

    // calcul itératif, supposant que nous avons 5 etudiants avec 5 notes, comme donné dans le dossier exemple etudiant
    char nom_fichier[50]="./etudiant/i/notej.txt";
    int j;
    int i;
    int Note_etudiant[5][5];  //note de tt les etudiants
    
    //boucle pour les 5 etudiants - recuperation de toute les notes d'apres les fichiers
    for(i=1;i<6;i++){
        //boucle pour les 5 notes
        for(j=1;j<6;j++){
            sprintf(nom_fichier,"./etudiant/%d/note%d.txt",i,j); 
            Note_etudiant[i-1][j-1]=lire_fichier(nom_fichier);
            printf("note %d de l'etudiant %d : %d\n",j,i,Note_etudiant[i-1][j-1]);
        }
    }

    //ici, la somme debute avec la premiere note
    //puis somme iterative de tout les etudiants
    int somme=Note_etudiant[0][0];
    char message_etudiant[50];
    char somme_int[100];
    
    for(i=0;i<5;i++){
        for(j=0;j<5;j++){

            printf("somme de etudiant %d note %d :\n",i+1,j+1);

            //ne pas reprendre la premiere note
            if(i==0 && j==0){
                printf("Initialisation: %d\n", somme);
                continue;
            }
            
            sprintf(message_etudiant,"calcule : + %d %d",somme,Note_etudiant[i][j]);
            strcpy(data, message_etudiant);

            // Envoie le message au serveur
            int write_status = write(socketfd, data, strlen(data));
            if (write_status < 0){
                perror("Erreur d'écriture");
                return -1;
            }

            // Reinitialise data
            memset(data, 0, sizeof(data));

            // Lit les données de la socket
            int read_status = read(socketfd, data, sizeof(data));
            if (read_status < 0){
                perror("Erreur de lecture");
                return -1;
            }
            
            // Affiche le message reçu du serveur
            printf("Message reçu: %s\n", data);
            sscanf(data, "Resultat : %s", somme_int);
            somme=atoi(somme_int); //recuperer le resultat en entier

            
        }
    
    }

    //mettre la valeur correspondant dans message_etudiant
    sprintf(message_etudiant,"calcule : / %d %d",somme,25);
    strcpy(data, message_etudiant);

    // Envoie le message au serveur
    int write_status = write(socketfd, data, strlen(data));
    if (write_status < 0){
        perror("Erreur d'écriture");
        return -1;
    }

    // Reinitialise data
    memset(data, 0, sizeof(data));

    // Lit les données de la socket
    int read_status = read(socketfd, data, sizeof(data));
    if (read_status < 0){
        perror("Erreur de lecture");
        return -1;
    }

    // Affiche le message reçu du serveur
    printf("Moyenne generale : %s\n", data);

    return 0; // Succès
}

int main(){
    int socketfd;
    char message[1024];
    struct sockaddr_in server_addr;

    /*
     * Creation d'une socket
     */
    socketfd = socket(AF_INET, SOCK_STREAM, 0);
    if (socketfd < 0){
    
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // détails du serveur (adresse et port)
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // demande de connection au serveur
    int connect_status = connect(socketfd, (struct sockaddr *)&server_addr, sizeof(server_addr));
    if (connect_status < 0){
    
        perror("connection serveur");
        exit(EXIT_FAILURE);
    }

    while (1){
        // demander à l'utilisateur de saisir un message
        printf("Votre message (max 1000 caractères): ");
        fgets(message, sizeof(message), stdin);
        // appeler la fonction pour envoyer un message au serveur
        //Declaration des variables 
        char calc[7];
        char deuxpoints[7];
        char op='/';
        int num1=1;
        int num2=2;
        char message2[1000];
        strcpy(message2,message);
        sscanf(message2, "%s %s %s %d %d", calc,deuxpoints,&op,&num1,&num2);
        int a=strncmp(calc,"calcule",7);
        //On vérifie si le message est un calcul

        //printf("%s %s %s %ls %ls", calc,deuxpoints,&op,&num1,&num2);
        if(strncmp(calc,"moyenne",7)==0){
            envoie_operateur_etudiant(socketfd,message);
        }
        // + note1 note2 "henry golade"
        
        else if (a==0 && deuxpoints[0]==':'){
            envoie_operateur_numeros(socketfd,message);
        }

        
        //Sinon on envoie un message
        else{
            envoie_recois_message(socketfd,message);
        }
    }
    return 0;
}

/*
Il faut ecrire  calcule : "op" num1 num2 pour realiser un calcul
                moyenne pour realiser la moyenne de tout les etudiants
                autre chose pour un message classique
*/