// Fichier: exemple.c
// Exercice 
// VENET ALEXIS
// le 08/11/2024

#include <stdio.h>


int main() {




}

/*

gcc -Wall -Wextra -o exemple exemple.c
./exemple

*/