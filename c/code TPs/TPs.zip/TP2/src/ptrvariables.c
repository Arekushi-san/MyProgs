// Fichier: ptrvariables.c
// TP1 Exercice 2.8
// VENET ALEXIS et RODDE THEOPHILE
// le 26/09/2024

#include <stdio.h>

int main() {

    //declaration des variables
    char Char = 'o';
    short Short = 123;
    int Int = 31456;
    long int LInt = 3145631456;
    long long int LLInt = 314563145631456;
    float Float = 3.14;
    double Double = 3.14654364;
    long double LDouble = 3.1465436414654364;

    //Declaration des pointeurs
    char *p_Char = &Char;
    short *p_Short = &Short;
    int *p_Int = &Int;
    long int *p_LInt = &LInt;
    long long int *p_LLInt = &LLInt;
    float *p_Float = &Float;
    double *p_Double = &Double;
    long double *p_LDouble = &LDouble;

    //affichage avant manipulation
    printf("Avant la manipulation :\n");
    printf("Adresse de Char : %p, Valeur de Char : %x\n",(void*)&Char, *p_Char);
    printf("Adresse de Short : %p, Valeur de Short : %x\n",(void*)&Short, *p_Short);
    printf("Adresse de Int : %p, Valeur de Int : %x\n",(void*)&Int, *p_Int);
    printf("Adresse de LInt : %p, Valeur de LInt : %lx\n",(void*)&LInt, *p_LInt);
    printf("Adresse de LLInt : %p, Valeur de LLInt : %llx\n",(void*)&LLInt, *p_LLInt);
    printf("Adresse de Float : %p, Valeur de Float : %x\n",(void*)&Float, *((unsigned int*)p_Float));
    printf("Adresse de Double : %p, Valeur de Double : %lx\n",(void*)&Double, *((unsigned long*)p_Double));
    printf("Adresse de LDouble : %p, Valeur de LDouble : %lx\n",(void*)&LDouble, *((unsigned long*)p_LDouble));

    //Manipulation des valeurs avec l'utilisation des pointeurs
    *p_Char='P';
    *p_Short=456;
    *p_Int=2222;
    *p_LInt=33334444;
    *p_LLInt=555555557777777;
    *p_Float=4.15;
    *p_Double=7.32133;
    *p_LDouble=2.99203113;

    //affichage apres manipulation
    printf("\nApres la manipulation :\n");
    printf("Adresse de Char : %p, Valeur de Char : %x\n",(void*)&Char, *p_Char);
    printf("Adresse de Short : %p, Valeur de Short : %x\n",(void*)&Short, *p_Short);
    printf("Adresse de Int : %p, Valeur de Int : %x\n",(void*)&Int, *p_Int);
    printf("Adresse de LInt : %p, Valeur de LInt : %lx\n",(void*)&LInt, *p_LInt);
    printf("Adresse de LLInt : %p, Valeur de LLInt : %llx\n",(void*)&LLInt, *p_LLInt);
    printf("Adresse de Float : %p, Valeur de Float : %x\n",(void*)&Float, *((unsigned int*)p_Float));
    printf("Adresse de Double : %p, Valeur de Double : %lx\n",(void*)&Double, *((unsigned long*)p_Double));
    printf("Adresse de LDouble : %p, Valeur de LDouble : %lx\n",(void*)&LDouble, *((unsigned long*)p_LDouble));

    return 0;
}

/*

gcc -Wall -Wextra -o ptrvariables ptrvariables.c
./ptrvariables

*/