// Fichier: chaine.c
// TP1 Exercice 2.4
// VENET ALEXIS et RODDE THEOPHILE
// le 23/09/2024

#include <stdio.h>

int main() {

    //declaration des variables
    char mot1[]="Hello";
    char mot2[]="World!";
    int i1;
    int i2;

    //boucle for qui calcul la taille de mot1
    for(i1=0;mot1[i1]!='\0';i1++){
        printf("%c",mot1[i1]);
    }
    printf("\nnombre de lettre dans mot 1 : %d\n",i1);

    //boucle for qui calcul la taille de mot1
    for(i2=0;mot2[i2]!='\0';i2++){
        printf("%c",mot2[i2]);
    }
    printf("\nnombre de lettre dans mot 2 : %d\n",i2);

    //declaration de variable pour copier le mot1
    char mot_copie[i1];
    int j;

    //boucle for permettant de copier le mot1
    for(j=0;j<=i1;j++){
        mot_copie[j]=mot1[j];
    }
    printf("\nmot copie : %s\n\n",mot_copie);


    //declaration de variable pour la concatenation de mot1 et mot2
    int j1;
    char mot1et2[50];

    //boucle for pour realiser la concatenation des deux mots
    for(j1=0;j1<=i1+i2;j1++){

        //condition permettant la copie du premier mot
        if(j1<i1){
            mot1et2[j1]=mot1[j1];
        }

        //condition pour ajouter un espace apres la copie du premier mot
        if(j1==i1){
            mot1et2[j1]=' ';
        }

        //condition pour ajouter le mot2 a la suite
        if(j1>i1){
            mot1et2[j1]=mot2[j1-i1-1];
        }

        //printf("%c",mot1et2[j1]); //test des charactere un a un
        
    }

    //affichage du mot concatene
    printf("\nmot concatene : %s \n",mot1et2);
    printf("\n");

    return 0;
    }

/*

gcc -Wall -Wextra -o chaine chaine.c
./chaine

*/
