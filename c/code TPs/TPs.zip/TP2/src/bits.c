// Fichier: bits.c
// TP1 Exercice 2.2
// VENET ALEXIS et RODDE THEOPHILE
// le 23/09/2024

#include <stdio.h>
#include <math.h>

int main() {

    //declaration des variables, INT etant la comparaison bit a bit de d et MASQUE
    int Masque = pow(2,3)+pow(2,19);
    int d = pow(2,4)+pow(2,3);
    int INT=d&Masque;

    //verification de la presence du 4eme et 20eme bit sur d
    if (INT==Masque){
        printf("1\n");
    }
    else{
        printf("0\n");
    }

return 0;
}

/*

gcc -Wall -Wextra -o bits bits.c
./bits

*/