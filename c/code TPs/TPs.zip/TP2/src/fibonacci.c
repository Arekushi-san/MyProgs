// Fichier: fibonacci.c
// TP1 Exercice 2.3
// VENET ALEXIS et RODDE THEOPHILE
// le 23/09/2024

#include <stdio.h>

    int main() {
    
    //declaration des variables
    int Unm2=0;//U0=0
    int Unm1=1;//U1=1
    int Un;
    int n;

    //saisi de n par l'utilisateur
    printf("valeur de n : ");
    scanf("%d", &n);

    //affichage des valeurs initiales
    printf("U0 = %i\n",Unm2);
    printf("U1 = %i\n",Unm1);

    //boucle for pour realiser la suite de fibonacci
    for(int i=2;i<=n;i++){
        Un=Unm1+Unm2;
        Unm2=Unm1;
        Unm1=Un;
        printf("U%i = %i\n",i,Un);
    }

    return 0;
}



/*

gcc -Wall -Wextra -o fibonacci fibonacci.c
./fibonacci

*/