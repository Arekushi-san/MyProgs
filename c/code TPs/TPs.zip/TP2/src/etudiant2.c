// Fichier: etudiant2.c
// TP1 Exercice 2.6
// VENET ALEXIS et RODDE THEOPHILE
// le 23/09/2024

#include <stdio.h>
#include <string.h>

int main() {

    //creation de la structure Etudiant
    struct Etudiant{
        char prenom_nom[60];
        char addresse[60];
        char note_1[30];
        char note_2[30];
    };

    //Creation des variables
    struct Etudiant etudiants[5];
    int i;
    char prenom_nom[60];
    char addresse[60];
    char note_1[30];
    char note_2[30];

    //boucle for permettant la saisi et l'enregistrement des donnees des 5 etudiants
    for(i=0;i<5;i++){
        printf("\nNom/prenom etudiant %i: ",i+1);
        fgets(prenom_nom,sizeof(prenom_nom),stdin);
        strcpy(etudiants[i].prenom_nom,prenom_nom);
        printf("%s",etudiants[i].prenom_nom);


        printf("Adresse etudiant %i: ",i+1);
        fgets(addresse,sizeof(addresse),stdin);
        strcpy(etudiants[i].addresse,addresse);
        printf("%s",etudiants[i].addresse);

        printf("\nNote 1 etudiant %i: ",i+1);
        fgets(note_1,sizeof(note_1),stdin);
        strcpy(etudiants[i].note_1,note_1);
        printf("%s",etudiants[i].note_1);

        printf("\nNote 2 etudiant %i: ",i+1);
        fgets(note_2,sizeof(note_2),stdin);
        strcpy(etudiants[i].note_2,note_2);
        printf("%s",etudiants[i].note_2);
   }


    //boucle for permettant l'affichage des donnees des 5 etudiants
    printf("\n");
    for(int i=0;i<5;i++){
        char inum1[30]="", inum2[30]="";
        sscanf(etudiants[i].prenom_nom, "%s %s", inum1, inum2);
        printf("Étudiant.e %i :\n",i+1);
        printf("Nom : %s",inum1);
        printf("\nPrenom : %s",inum2);
        printf("\naddresse : %s",etudiants[i].addresse);
        printf("Note 1 : %s",etudiants[i].note_1);
        printf("Note 2 : %s\n",etudiants[i].note_2);
    }
return 0;
}

/*

gcc -Wall -Wextra -o etudiant2 etudiant2.c
./etudiant2


Dupont Marchal
29, rue victoire, Lyon
11.0
13.0
Lama Stico
12, rue victoire, Lyon
11.0
13.0
Jean Nenpeplu
12, rue largo, Lyon
15.0
7.0
Thierry Golade
14, rue miel, Lyon
14.0
11.0
Henry Golade
1, rue miel, Lyon
1.0
1.0

Pour plus de facilite, lors de la proposition de la saisi, veuillez selectionner
corectement les informations ci-dessus et les coller dans l'espace de saisi, puis
appuyer sur entrer.

*/