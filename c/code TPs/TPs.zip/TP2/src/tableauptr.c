// Fichier: tableauptr.c
// TP1 Exercice 2.9
// VENET ALEXIS et RODDE THEOPHILE
// le 26/09/2024

#include <stdio.h>

int main() {

    //Declaration des tableaux
    int Tableau_i[8]={2,4,3,5,6,8,10,12};
    float Tableau_f[8]={2.12,4.267,3.5,5.72,6.102,8.404,10.128,12.3};

    //Declaration des pointeurs
    int *i_ptr=&(*Tableau_i);
    float *f_ptr=&(*Tableau_f);
    
    
    printf("\nTableau d'entiers (avant la multiplication par 3) :\n");
    printf("```\n");

    //Boucle for pour afficher tableau_i
    for(int i=0;i<8;i++){
        printf("%i ",*i_ptr);
        i_ptr+=1;
        if(i!=7){
            printf(",");
        }
    }
    printf("\n```\n\n");

    printf("Tableau de nombres à virgule flottante (avant la multiplication par 3) :\n");
    printf("```\n");
    //Boucle for pour afficher tableau_f
    for(int i=0;i<8;i++){
        printf("%f ",*f_ptr);
        f_ptr+=1;
        if(i!=7){
            printf(",");
        }
    }
    printf("\n```\n\n");
    
    //Re initialisation des pointeurs
    i_ptr=&(*Tableau_i);
    f_ptr=&(*Tableau_f);

    //boucle for pour afficher toutes les valeurs des tableaux, et multiplie par 3 les indices paires (sauf pour indice 2)
    for(int i=1;i<=8;i++){
        if((i%2==0) & (i!=1) & (i!=2)){
            *i_ptr=*i_ptr*3;
            *f_ptr=*f_ptr*3;
        }
        i_ptr+=1;
        f_ptr+=1;
    }

    //Re Re initialisation des pointeurs
    i_ptr=&(*Tableau_i);
    f_ptr=&(*Tableau_f);

    printf("\nTableau d'entiers (après la multiplication par 3) :\n");
    printf("```\n");

    //Boucle for pour afficher tableau_i
    for(int i=0;i<8;i++){
        printf("%i ",*i_ptr);
        i_ptr+=1;
        if(i!=7){
            printf(",");
        }
    }
    printf("\n```\n\n");

    printf("Tableau de nombres à virgule flottante (après la multiplication par 3) :\n");
    printf("```\n");

    //Boucle for pour afficher tableau_f
    for(int i=0;i<8;i++){
        printf("%f ",*f_ptr);
        f_ptr+=1;
        if(i!=7){
            printf(",");
        }
    }
    printf("\n```\n\n");



    return 0;
}

/*

gcc -Wall -Wextra -o tableauptr tableauptr.c
./tableauptr

*/