// Fichier: couleurs.c
// TP1 Exercice 2.7
// VENET ALEXIS et RODDE THEOPHILE
// le 23/09/2024

#include <stdio.h>
#include <string.h>

int main() {

    //creation de la structure Couleurs
    struct Couleurs{
        int couleur;
        int rouge;
        int vert;
        int bleu;
        int alpha;
    };

    //creation d'une liste d'objets de la structure Couleurs
    struct Couleurs color[10] = {
        {1,0xef,0x78,0x12,0xff},

        {2,0x12,0x34,0x56,0x78},

        {3,0x12,0x34,0x56,0x78},

        {4,0x12,0x34,0x56,0x78},
        
        {5,0x12,0x34,0x57,0x78},

        {6,0x12,0x34,0x59,0x78},

        {7,0x12,0x34,0x35,0x78},

        {8,0x12,0x34,0x75,0x70},

        {9,0x12,0x34,0x56,0xd2},

        {10,0x12,0xc3,0xbd,0x78}
    };


    //boucle for permettant de parcourir la liste d'objet et d'afficher leurs valeurs
    for(int i=0;i<10;i++){
        printf("Couleur: %d\n",color[i].couleur);
        printf("Rouge: %d\n",color[i].rouge);
        printf("Vert: %d\n",color[i].vert);
        printf("Bleu: %d\n",color[i].bleu);
        printf("Alpha: %d\n",color[i].alpha);
        printf("\n");

    }

    return 0;
}

/*

gcc -Wall -Wextra -o couleurs couleurs.c
./couleurs

*/