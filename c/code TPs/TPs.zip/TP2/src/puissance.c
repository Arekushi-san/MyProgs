// Fichier: puissance.c
// TP1 Exercice 2.1
// VENET ALEXIS et RODDE THEOPHILE
// le 23/09/2024

#include <stdio.h>

int main() {
    
    //declaration des variables
    int a=2;
    int b=3;
    int Calc=1;

    //boucle for permettant que a se multiplie par lui meme b fois
    for(int i=1;i<=b;i++){
        Calc=Calc*a;
    }

    printf("a^b = %i\n",Calc);

    return 0;
}

/*

gcc -Wall -Wextra -o puissance puissance.c
./puissance

*/