// Fichier: etudiant.c
// TP1 Exercice 2.5
// VENET ALEXIS et RODDE THEOPHILE
// le 23/09/2024

#include <stdio.h>

int main() {

    //creation de la structure Etudiant
    struct Etudiant{
        char prenom_nom[60];
        char addresse[60];
        float note_prog[50];
        float note_sys[50];
    };

    //creation d'une liste d'objets de la structure Etudiant
    struct Etudiant etudiants[5] = {
        {"Dupont Marchal","29 rue victoire",{11.0,12.0,13.0},{13.0,14.5,13.0}},
        {"Lama Stico","12 rue victoire",{11.0,12.0,13.0},{13.0,14.5,13.0}},
        {"Jean Nenpeplu","12 rue largo",{15.0,16.5,13.0},{7.0,8.5,9.0}},
        {"Thierry Golade","14 rue miel",{14.0,11.0,12.0},{11.0,11.5,11.0}},
        {"Henry Golade","1 rue miel",{1.0,1.0,1.0},{1.0,20.0,0.0}}
    };

    //boucle for afin d'afficher tout les valeurs assiciees aux 5 eleves
    for(int i=0;i<5;i++){
        printf("\nprenom et nom de l'etudiant : %s\n",etudiants[i].prenom_nom);
        printf("addresse : %s\n",etudiants[i].addresse);


        printf("note programmation : \n");
        //boucle for afin d'afficher une a une les notes du module programmation
        for(int j=0;j<3;j++){
            printf("Note %i : %.1f\n",j+1,etudiants[i].note_prog[j]);
        }

        printf("note systeme exploitation : \n");
        //boucle for afin d'afficher une a une les notes du module systeme exploitation
        for(int j=0;j<3;j++){
            printf("Note %i : %.1f\n",j+1,etudiants[i].note_sys[j]);
        }
    }

    return 0;
}

/*

gcc -Wall -Wextra -o etudiant etudiant.c
./etudiant

*/