On a realise l'ensemble des exercices du TP2

bibliotheque utilise :
#include <stdio.h>
#include <math.h>
#include <string.h>

Groupe A

niveau de difficulté : facile

Commentaires :

    bit.c : 
    On a verifier si le 4eme bit et le 20eme bit etaint egales a 1.
    On a applique un masque qui permet de recuperer ces valeurs.
    si on a toujours le masque sur la comparaison, alors ces deux bits sont
    bien presents.

    etudiant.c :
    On a utilise lors du printf pour afficher la valeur
    %.1f, qui permet de voir 1 chiffre après la virgule seulement

    ptrvariables.c :
    Pour afficher la valeur hexadecimal du float, double et long double, specifier lors de l'appel de la
    valeur avec le pointeur leur type.  

    etudiant2.c :
    Pour cette exercice, le but est de faire entrer par l'utilisateur l'information des 5 etudiants.
    Afin de simplifier cette rentree, on peut mettre sur chaque ligne une information sur l'etudiant