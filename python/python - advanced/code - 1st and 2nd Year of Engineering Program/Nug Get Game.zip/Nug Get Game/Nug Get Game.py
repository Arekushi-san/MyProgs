#work with Thonny

#importation des modules
from random import*
from tkinter import*
import tkinter as tk
import time
import simpleaudio
import threading

#création de la fenêtre
Win = Tk()
Win.title("Nug Get Game")
Win.iconbitmap("icone.ico")
Win.geometry("720x720+600+120")
Win.focus()
Win.resizable(width=False, height=False)

#écran de jeu #4f9ad9
Screen = Canvas(Win, bg="#3f7bae", width=720, height=720)
Screen.pack()

#importation des images
ImgLogo = tk.PhotoImage(file="textures\\interface\\logo.png")
ImgBarreEspace = tk.PhotoImage(file="textures\\interface\\barre_espace.png")
ImgControles = tk.PhotoImage(file="textures\\interface\\controles.png")
ImgGameOver = tk.PhotoImage(file="textures\\interface\\game_over.png")
ImgVictoire = tk.PhotoImage(file="textures\\interface\\victoire.png")
# ---
ImgMurs = tk.PhotoImage(file="textures\\niveaux\\murs.png")
ImgNiveau = tk.PhotoImage(file="textures\\niveaux\\niveau_0.png")
# ---
ImgPerso = tk.PhotoImage(file="textures\\personnage\\droite.png")

#importation des sons
MusiqueMenu = simpleaudio.WaveObject.from_wave_file("audio\\ecran_titre.wav")
MusiqueNiveaux = simpleaudio.WaveObject.from_wave_file("audio\\jeu.wav")
MusiqueBoss = simpleaudio.WaveObject.from_wave_file("audio\\boss.wav")
MusiqueVictoire = simpleaudio.WaveObject.from_wave_file("audio\\victoire.wav")
MusiqueMuette = simpleaudio.WaveObject.from_wave_file("audio\\muet.wav")
SonGameOver = simpleaudio.WaveObject.from_wave_file("audio\\game_over.wav")
SonSaut = simpleaudio.WaveObject.from_wave_file("audio\\saut.wav")


def dans_le_vide():
    global vecteur_y, mode, tag_niveau, spawn, points_tp, solides, semisolides, zones_dangers, ennemis, Logo, BarreEspace, Controles, x, y, au_sol, direction, piste, en_cours_gravite
    au_sol = False
    print("a")
    vecteur_y = 0
    for i in solides:
        if (0 >= i[0][1] - y - 54 > vecteur_y) and (i[0][0] - 35 < x < i[1][0]):
            au_sol = True
    for i in semisolides:
        if (0 >= i[0][1] - y - 54 > vecteur_y) and (i[0][0] - 35 < x < i[1][0]):
            au_sol = True
    if au_sol == False and en_cours_gravite == False:
        gravite()
    


def detection_touche(event):
    global vecteur_y, mode, tag_niveau, spawn, points_tp, solides, semisolides, zones_dangers, ennemis, Logo, BarreEspace, Controles, x, y, au_sol, direction, piste, en_cours_gravite
    touche = event.keysym
    if mode == 0:
        if touche == "space":
            mode = 1
            texte_clignotant()
            Screen.delete(Logo)
            Controles = Screen.create_image(120, 60, anchor=tk.NW, image=ImgControles)
            Screen.move(BarreEspace, 0, 120)
            mode = 2
    elif mode == 2:
        if touche == "space":
            mode = 2.5
            texte_clignotant()
            Screen.delete(Controles)
            Screen.delete(BarreEspace)
            mode = 3
            tag_niveau = 1
            niveau()
            nug_get()
            simpleaudio.stop_all()
            piste = 1
            threading.Thread(target=gravite()).start()
    elif mode == 3:
        if touche == "Left":
            direction = 1
            mur_rencontre = False
            if (0 <= x - 52 < 10):
                x = 52
                mur_rencontre = True
                if au_sol == True:
                    ImgPerso.configure(file="textures\\personnage\\gauche.png")
            else:
                for i in solides:
                    if (0 <= x - i[1][0] < 10) and (i[0][1] - 54 < y < i[1][1]):
                        x = i[1][0]
                        mur_rencontre = True
                        if au_sol == True:
                            ImgPerso.configure(file="textures\\personnage\\gauche.png")
            if mur_rencontre == False and (x - 52 >= 10 or 0 >= x - 52):
                x = x - 10
                if au_sol == True:
                    if 0 <= time.time() % 0.25 < 0.125:
                        ImgPerso.configure(file="textures\\personnage\\gauche_marche.png")
                    else:
                        ImgPerso.configure(file="textures\\personnage\\gauche.png")
            Screen.coords(Perso, x, y)
        elif touche == "Right":
            direction = 0
            mur_rencontre = False
            if (0 <= 633 - x < 10):
                x = 633
                mur_rencontre = True
                if au_sol == True:
                    ImgPerso.configure(file="textures\\personnage\\droite.png")
            else:
                for i in solides:
                    if (0 <= i[0][0] - x - 35 < 10) and (i[0][1] - 54 < y < i[1][1]):
                        x = i[0][0] - 35
                        mur_rencontre = True
                        if au_sol == True:
                            ImgPerso.configure(file="textures\\personnage\\droite.png")
            if mur_rencontre == False and (633 - x >= 10 or 0 >= 633 - x):
                x = x + 10
                if au_sol == True:
                    if 0 <= time.time() % 0.25 < 0.125:
                        ImgPerso.configure(file="textures\\personnage\\droite_marche.png")
                    else:
                        ImgPerso.configure(file="textures\\personnage\\droite.png")
            Screen.coords(Perso, x, y)
        if touche == "space" and au_sol == True:
            au_sol = False
            son_saut = SonSaut.play()
            vecteur_y = 18
            gravite()
    elif mode == 4:
        if touche == "space":
            Screen.delete(ecran_game_over)
            mode = 3
            tag_niveau = 1
            niveau()
            nug_get()
            simpleaudio.stop_all()
            piste = 1
            stop_musique = False



def fin():
    simpleaudio.stop_all()
    ecran_de_fin = Screen.create_image(0, 0, anchor=tk.NW, image=ImgVictoire)
    jingle_de_victoire = MusiqueVictoire.play()
    Win.update()
    Win.after(8000)
    ImgVictoire.configure(file="textures\\interface\\bis.png")
    Screen.coords(ImgVictoire, 0, 0)
    Win.update()
    Win.after(500)
    exit()
        


def gravite():
    global x, y, au_sol, vecteur_y, points_tp, solides, semisolides, zones_dangers, ennemis, en_cours_gravite, direction
    en_cours_gravite = True
    if direction == 1:
        ImgPerso.configure(file="textures\\personnage\\gauche_saut.png")
    else:
        ImgPerso.configure(file="textures\\personnage\\droite_saut.png")
    while au_sol == False:
        while vecteur_y > 0:
            plafond_rencontre = False
            for i in solides:
                if (0 <= y - i[1][1] < vecteur_y) and (i[0][0] - 35 < x < i[1][0]):
                    y = i[1][1]
                    plafond_rencontre = True
                    vecteur_y = 0
            if plafond_rencontre == False:
                y = y - vecteur_y
                vecteur_y = vecteur_y - 1
            Screen.coords(Perso, x, y)
            Win.after(35)
            Win.update()
        for i in solides:
            if (0 >= i[0][1] - y - 54 > vecteur_y) and (i[0][0] - 35 < x < i[1][0]):
                y = i[0][1] - 54
                au_sol = True
                vecteur_y = 0
        for i in semisolides:
            if (0 >= i[0][1] - y - 54 > vecteur_y) and (i[0][0] - 35 < x < i[1][0]):
                y = i[0][1] - 54
                au_sol = True
                vecteur_y = 0
        if au_sol == False:
            y = y - vecteur_y 
            if vecteur_y > -18:
                vecteur_y = vecteur_y - 1
        Screen.coords(Perso, x, y)
        if vecteur_y < 0:
            Win.after(35)
            Win.update()
    if direction == 1:
        ImgPerso.configure(file="textures\\personnage\\gauche.png")
    else:
        ImgPerso.configure(file="textures\\personnage\\droite.png")
    en_cours_gravite = False
        
        

def jouer_musique():
    global piste
    while 1 == 1:
        if piste == 0:
            musique0 = MusiqueMenu.play()
            if stop_musique == False:
                musique0.wait_done()
            else:
                musique0.stop()
        if piste == 1:
            musique1 = MusiqueNiveaux.play()
            if stop_musique == False:
                musique1.wait_done()
            else:
                musique1.stop()
        elif piste == 2:
            musique2 = MusiqueBoss.play()
            if stop_musique == False:
                musique2.wait_done()
            else:
                musique2.stop()
        
    
        

def niveau():
    global tag_niveau, Niveau, ImgNiveau, Perso, ImgPerso, spawn, points_tp, solides, semisolides, zones_dangers, ennemis, x, y, direction, phase_animation
    if tag_niveau == -1:
        ImgNiveau.configure(file="textures\\niveaux\\niveau_minus1.png")
        spawn = [90, 627, 0]
        points_tp = []
        solides = [ [[0, 628], [720, 720]] ]
        semisolides = []
        zones_dangers = []
        ennemis = []
    if tag_niveau == 1:
        ImgNiveau.configure(file="textures\\niveaux\\niveau_1.png")
        spawn = [90, 627, 0]
        points_tp = [ [[156, -27], [256, -17]] ]
        solides = [ [[0, 0], [156, 13]],   [[256, 0], [720, 13]],   [[0, 629], [720, 720]] ]
        semisolides = [ [[172, 156], [278, 156]],   [[438, 283], [534, 283]],   [[231, 407], [336, 407]],   [[461, 521], [544, 521]] ]
        zones_dangers = []
        ennemis = []
    if tag_niveau == 2:
        ImgNiveau.configure(file="textures\\niveaux\\niveau_2.png")
        spawn = [190, 627, 0]
        points_tp = [ [[470, -27], [571, -17]] ]
        solides = [ [[0, 0], [470, 18]],   [[571, 0], [720, 18]],   [[0, 629], [440, 720]],  [[340, 513], [440, 720]] ]
        semisolides = [ [[394, 129], [498, 129]],   [[587, 233], [668, 233]],   [[452, 381], [556, 381]] ]
        zones_dangers = [ [[441, 682], [720, 720]] ]
        ennemis = []
    if tag_niveau == 3:
        ImgNiveau.configure(file="textures\\niveaux\\niveau_3_ferme.png")
        spawn = [520, 627, 0]
        points_tp = [ [[112, 605], [134, 638]] ]
        solides = [ [[0, 0], [720, 13]],   [[0, 628], [720, 720]] ]
        semisolides = [ [[414, 511], [449, 522]],   [[276, 428], [312, 435]],   [[444, 334], [491, 346]],   [[350, 212], [389, 223]],   [[200, 144], [252, 151]] ]
        zones_dangers = []
        ennemis = []
    if tag_niveau == 4:
        ImgNiveau.configure(file="textures\\niveaux\\niveau_3_ouvert.png")
        spawn = [126, 627, 0]
        points_tp = [ [[116, -27], [217, -17]] ]
        solides = [ [[0, 0], [116, 13]],   [[217, 0], [720, 13]],   [[0, 629], [720, 720]] ]
        semisolides = [ [[414, 511], [449, 522]],   [[276, 428], [312, 435]],   [[444, 334], [491, 346]],   [[350, 212], [389, 223]],   [[200, 144], [252, 151]] ]
        zones_dangers = []
        ennemis = []
    if tag_niveau == 5:
        ImgNiveau.configure(file="textures\\niveaux\\niveau_4.png")
        spawn = [156, 627, 0]
        points_tp = [ [[116, -27], [217, -17]] ]
        solides = [ [[0, 0], [116, 13]],   [[217, 0], [720, 13]],   [[0, 629], [720, 720]] ]
        semisolides = [ [[146, 147], [181, 147]],   [[146, 282], [181, 282]],   [[273, 391], [554, 391]],   [[633, 510], [720, 510]] ]
        zones_dangers = [ [[293, 591], [329, 628]],   [[427, 591], [463, 628]],   [[560, 591], [596, 628]],   [[352, 353], [388, 390]],   [[486, 353], [522, 390]] ]
        ennemis = []
    if tag_niveau == 6:
        ImgNiveau.configure(file="textures\\niveaux\\niveau_5_ferme.png")
        spawn = [156, 627, 0]
        points_tp = [ [[229, 144], [250, 164]] ]
        solides = [ [[0, 0], [720, 13]],   [[0, 629], [720, 720]],   [[633, 441], [720, 720]],   [[658, 0], [720, 720]] ]
        semisolides = [ [[151, 428], [186, 428]],   [[151, 528], [186, 528]],   [[236, 365], [492, 365]],   [[542, 328], [277, 328]],   [[615, 241], [651, 241]],   [[187, 165], [557, 165]] ]
        zones_dangers = [ [[484, 144], [505, 164]],   [[267, 377], [303, 414]],   [[401, 377], [437, 414]],   [[339, 591], [375, 628]],   [[521, 591], [596, 628]] ]
        ennemis = []
    if tag_niveau == 7:
        ImgNiveau.configure(file="textures\\niveaux\\niveau_5_ouvert.png")
        spawn = [242, 164, 0]
        points_tp = [ [[628, 0], [738, 720]] ]
        solides = [ [[0, 0], [720, 13]],   [[0, 629], [720, 720]],   [[633, 441], [720, 720]] ]
        semisolides = [ [[151, 428], [186, 428]],   [[151, 528], [186, 528]],   [[236, 365], [492, 365]],   [[542, 328], [277, 328]],   [[615, 241], [651, 241]],   [[187, 165], [557, 165]] ]
        zones_dangers = [ [[484, 144], [505, 164]],   [[267, 377], [303, 414]],   [[401, 377], [437, 414]],   [[339, 591], [375, 628]],   [[521, 591], [596, 628]] ]
        ennemis = []
    if tag_niveau == 8:
        ImgNiveau.configure(file="textures\\niveaux\\niveau_6.png")
        spawn = [235, 628, 0]
        points_tp = [ [[558, 553], [645, 628]] ]
        solides = [ [[0, 0], [720, 13]],   [[0, 629], [720, 720]] ]
        semisolides = [ [[198, 445], [248, 445]],   [[126, 533], [176, 533]],   [[285, 553], [335, 553]] ]
        zones_dangers = []
        ennemis = []
    Screen.coords(Niveau, 0, 0)
    if spawn[2] == 1:
        direction = 1
        ImgPerso.configure(file="textures\\personnage\\gauche.png")
    else:
        direction = 0
        ImgPerso.configure(file="textures\\personnage\\droite.png")
    x, y = spawn[0] - 18, spawn[1] - 54
    Screen.delete(Perso)
    Perso = Screen.create_image(x, y, anchor=tk.NW, image=ImgPerso)
    Screen.coords(Murs, 0, 0)
    


#contrôle du personnage et détection de collisions avec celui-ci
def nug_get():
    global ecran_game_over, Niveau, mode, spawn, points_tp, solides, semisolides, zones_dangers, ennemis, x, y, direction, phase_animation, tag_niveau, piste, ImgGameOver
    if mode == 3:
        for i in points_tp: 
            #collision par le milieu des bords de la boîte de collision du personnage
            if (( i[0][0] < x + 18 < i[1][0] ) and ( i[0][1] < y < i[1][1] )) or (( i[0][0] < x + 35 < i[1][0] ) and ( i[0][1] < y + 27 < i[1][1] )) or (( i[0][0] < x < i[1][0] ) and ( i[0][1] < y + 27 < i[1][1] )) or (( i[0][0] < x + 18 < i[1][0] ) and ( i[0][1] < y + 54 < i[1][1] )):
                if tag_niveau < 8:
                    tag_niveau = tag_niveau + 1
                    niveau()
                else:
                    mode = 4
                    fin()

        for i in zones_dangers: 
            #collision par le milieu des bords de la boîte de collision du personnage
            if (( i[0][0] < x + 18 < i[1][0] ) and ( i[0][1] < y < i[1][1] )) or (( i[0][0] < x + 35 < i[1][0] ) and ( i[0][1] < y + 27 < i[1][1] )) or (( i[0][0] < x < i[1][0] ) and ( i[0][1] < y + 27 < i[1][1] )) or (( i[0][0] < x + 18 < i[1][0] ) and ( i[0][1] < y + 54 < i[1][1] )):
                mode = 4
                ecran_game_over = Screen.create_image(0, 0, anchor=tk.NW, image=ImgGameOver)
                simpleaudio.stop_all()
                piste = -1
                gameover = SonGameOver.play()
                
        for i in ennemis: 
            #collision par le milieu des bords de la boîte de collision du personnage
            if (( i[0][0] < x + 18 < i[1][0] ) and ( i[0][1] < y < i[1][1] )) or (( i[0][0] < x + 35 < i[1][0] ) and ( i[0][1] < y + 27 < i[1][1] )) or (( i[0][0] < x < i[1][0] ) and ( i[0][1] < y + 27 < i[1][1] )):
                mode = 4
                ecran_game_over = Screen.create_image(0, 0, anchor=tk.NW, image=ImgGameOver)
                simpleaudio.stop_all()
                piste = -1
                gameover = SonGameOver.play()
            elif (( i[0][0] < x + 18 < i[1][0] ) and ( i[1][1] < y + 54 < i[1][1] )):
                ennemis[i[3]] = [[9999, 9999], [9999, 9999], 0, i[3]]
                
        Win.after(5,nug_get)


def texte_clignotant(): #fait clignoter le texte "appuyez sur la barre espace"
    global BarreEspace
    for i in range(5):
        Screen.move(BarreEspace, 0, 720)
        Win.after(50)
        Win.update()
        Screen.move(BarreEspace, 0, -720)
        Win.after(50)
        Win.update()
    Win.after(500)

#initialisation
Logo = Screen.create_image(120, 40, anchor=tk.NW, image=ImgLogo)
BarreEspace = Screen.create_image(120, 400, anchor=tk.NW, image=ImgBarreEspace)
tag_niveau = 0
#pour les niveaux
spawn = [0, 0, 0]
points_tp = []
solides = []
semisolides = []
zones_dangers = []
ennemis = []
#pour le personnage
x, y = 0, 0
au_sol = True
vecteur_y = 0
direction = 0
en_cours_gravite = False

Perso = Screen.create_image(9999, 9999, anchor=tk.NW, image=ImgPerso)
#pour le décor
Niveau = Screen.create_image(9999, 9999, anchor=tk.NW, image=ImgNiveau)
Murs = Screen.create_image(9999, 9999, anchor=tk.NW, image=ImgMurs)

#pour le reste
mode = 0
piste = 0
stop_musique = False
def fermeture_jeu():
    exit()


#boucle en parallèle
thread_musique = threading.Thread(target=jouer_musique)
thread_musique.start()

#enregistrement d'actions
Win.bind('<Key>', detection_touche)
Win.protocol("WM_DELETE_WINDOW", fermeture_jeu)
Win.mainloop()